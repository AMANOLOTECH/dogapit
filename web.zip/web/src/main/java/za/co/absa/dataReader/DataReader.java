package za.co.absa.dataReader;

import za.co.absa.customexceptions.DataNotFoundException;

import java.io.*;
import java.util.Properties;

public class DataReader {
    Properties properties;
    private static final String TEST_DATA_PROPERTY_FILE_PATH = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testData" + File.separator + "testData.properties";
    public DataReader() throws IOException{
        try (BufferedReader reader = new BufferedReader(new FileReader(TEST_DATA_PROPERTY_FILE_PATH))){
            properties = new Properties();
            readProperties(properties, reader);
        }catch (FileNotFoundException e){
            throw new FileNotFoundException("Required file not found: " + TEST_DATA_PROPERTY_FILE_PATH);
        }
    }

    private void readProperties(Properties properties, BufferedReader reader){
        try {
            properties.load(reader);
            reader.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public String getRequiredData(String requiredData) throws DataNotFoundException{
        String data = properties.getProperty(requiredData);
        if (data != null) return data;
        throw new DataNotFoundException("Required data not found in " + TEST_DATA_PROPERTY_FILE_PATH);
    }
}
