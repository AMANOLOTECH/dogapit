package za.co.absa.webPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import za.co.absa.Base.BaseClass;

public class HomeLoanBuyAHomePropertyDetailsPage {
    WebDriver driver;
    BaseClass baseClass;

    public HomeLoanBuyAHomePropertyDetailsPage(WebDriver driver) {
        this.driver = driver;
        baseClass = new BaseClass(this.driver);
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(name = "sellersIdType")
    private WebElement slctCurrOwnerIdentityType;

    @FindBy(name = "sellersIdPassport")
    private WebElement txtSellerIdNumber;

    @FindBy(name = "streetName")
    private WebElement txtStreetName;

    @FindBy(name = "erfNumber")
    private WebElement txtErfNumber;

    @FindBy(name = "streetNumber")
    private WebElement txtStreetNumber;

    @FindBy(name = "suburbName")
    private WebElement txtSuburbName;

    @FindBy(name = "button_promptSearchSuburb")
    private WebElement btnSuburbSearch;

    @FindBy(xpath = "//a[@class=\"linkText\"]")
    private WebElement lnkResult;

    @FindBy(name = "wallType")
    private WebElement sltWalltype;

    @FindBy(name = "roofType")
    private WebElement sltRoofType;

    @FindBy(xpath = "//input[@name = \"thatchRoof\" and @value = \"Y\"]")
    private WebElement chkIsThereThatchInPropYes;

    @FindBy(xpath = "//input[@name = \"thatchRoof\" and @value = \"N\"]")
    private WebElement chkIsThereThatchInPropNo;

    @FindBy(xpath = "//input[@name = \"primaryResidenceIndicator\" and @value = \"Y\"]")
    private WebElement chkPrimaryResidenceYes;

    @FindBy(xpath = "//input[@name = \"primaryResidenceIndicator\" and @value = \"N\"]")
    private WebElement chkPrimaryResidenceNo;

    @FindBy(name = "valuationContactName")
    private WebElement txtValuationContactName;

    @FindBy(name = "bondAttName")
    private WebElement txtBondAttorneyName;

    @FindBy(name = "button_promptSearchTransferAttorney")
    private WebElement btnAttorneyNameSearch;


    @FindBy(name = "button_processPropertyDetails")
    private WebElement btnSearchProperty;

    @FindBy(name = "button_notFoundProperty")
    private WebElement btnNotFound;

    @FindBy(name = "button_processPropertyDetails")
    private WebElement btnAcceptProperty;


    @FindBy(name = "main")
    private WebElement frameMain;

    public void selectCurrentOwnerIdentityType(String identityNumber) {
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        baseClass.selectOptionByText(slctCurrOwnerIdentityType, identityNumber);
    }

    public void captureSellerID(String sellerId){
        baseClass.captureText(sellerId, txtSellerIdNumber);
    }

    public String getID(String id){
        return id;
    }

    public void captureStreetName(String streetName){
        baseClass.captureText(streetName, txtStreetName);
    }

    public void captureErfNumber(String erfNumber){
        baseClass.captureText(erfNumber, txtErfNumber);
    }

    public void captureStreetNumber(String streetNumber){
        baseClass.captureText(streetNumber, txtStreetNumber);
    }

    public void captureSuburbName(String suburbName){
        baseClass.captureText(suburbName, txtSuburbName);
    }

    public void clickSuburbSearchButton(){
        baseClass.clickObject(btnSuburbSearch);
    }

    public void clickResultFromSearch(){
        baseClass.clickObject(lnkResult);
    }

    public void selectWallType(String wallType){
        baseClass.selectOptionByText(sltWalltype, wallType);
    }

    public void selectRoofType(String roofType){
        baseClass.selectOptionByText(sltRoofType, roofType);
    }

    public void clickThatchRoofYesOrNo(boolean thatchRoofOption){
        WebElement element = null;

        if(thatchRoofOption){
            element = chkIsThereThatchInPropYes;
        }else {
            element = chkIsThereThatchInPropNo;
        }

        baseClass.clickObject(element);
    }

    public void clickPrimaryResidenceYesOrNo(boolean primaryResidenceOption){
        WebElement element = null;

        if(primaryResidenceOption){
            element = chkPrimaryResidenceYes;
        }else {
            element = chkPrimaryResidenceNo;
        }

        baseClass.clickObject(element);
    }

    public void captureValuationContactName(String valuationName){
        baseClass.captureText(valuationName, txtValuationContactName);
    }

    public void captureBondAttorneyName(String attorneyName){
        baseClass.captureText(attorneyName, txtBondAttorneyName);
    }

    public void clickAttorneyNameSearchButton(){
        baseClass.clickObject(btnAttorneyNameSearch);
    }

    public void clickSearchPropertyButton(){
        baseClass.clickObject(btnSearchProperty);
    }

    public void clickNotFound(){
        baseClass.clickObject(btnNotFound);
    }

    public void clickAcceptPropertyButton(){
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        baseClass.clickObject(btnAcceptProperty);
    }

}
