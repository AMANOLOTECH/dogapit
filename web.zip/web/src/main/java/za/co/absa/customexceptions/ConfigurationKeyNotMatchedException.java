package za.co.absa.customexceptions;

public class ConfigurationKeyNotMatchedException extends Exception{
    public ConfigurationKeyNotMatchedException(String s){
        super(s);
    }
}
