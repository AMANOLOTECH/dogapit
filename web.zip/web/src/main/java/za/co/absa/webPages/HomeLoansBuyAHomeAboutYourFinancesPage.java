package za.co.absa.webPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import za.co.absa.Base.BaseClass;

public class HomeLoansBuyAHomeAboutYourFinancesPage {
    WebDriver driver;
    BaseClass baseClass;

    public HomeLoansBuyAHomeAboutYourFinancesPage(WebDriver driver) {
        this.driver = driver;
        baseClass = new BaseClass(this.driver);
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(xpath = "//select[@name=\"preferredCommChannel\"]")
    private WebElement slctPreferredCommChannel;

    @FindBy(xpath = "//input[@name=\"cellNo\"]")
    private WebElement txtCellNumber;

    @FindBy(xpath = "//input[@name=\"email\"]")
    private WebElement txtEmailAddress;

    @FindBy(xpath = "//input[@name=\"surname1\"]")
    private WebElement txtSurname;

    @FindBy(xpath = "//input[@name=\"fullNames1\"]")
    private WebElement txtFullNames;

    @FindBy(xpath = "//select[@name=\"identificationType1\"]")
    private WebElement slctIDType;

    @FindBy(xpath = "//input[@name=\"idOrPassportNo1\"]")
    private WebElement txtIDNumber;

    @FindBy(xpath = "//select[@name=\"occupationStatus1\"]")
    private WebElement slctEmploymentStatus;

    @FindBy(xpath = "//input[@name=\"incomeBracket1\" and @value=\"2\"]")
    private WebElement chkIncomeBracketTwo;

    @FindBy(xpath = "//select[@name = \"maritalStatus1\"]")
    private WebElement slctMaritalStatus;

    @FindBy(xpath = "//input[@value = \"Continue\"]")
    private WebElement btnContinue;

    @FindBy(xpath = "//input[@name = \"button_complete\"]")
    private WebElement btnComplete;

    @FindBy(name = "title")
    private WebElement slctTitle;

    @FindBy(name = "participantInput")
    private WebElement chkParticipantInput;

    @FindBy(name = "countryOfBirth")
    private WebElement slctCountyOfBirth;

    @FindBy(name = "nationality")
    private WebElement slctNationality;

    @FindBy(name = "race")
    private WebElement slctRace;

    @FindBy(xpath = "//input[@name= \"postMatricQualification\" and @value = \"Y\"]")
    private WebElement chkPostMatricQualificationYes;

    @FindBy(xpath = "//input[@name= \"postMatricQualification\" and @value = \"N\"]")
    private WebElement chkPostMatricQualificationNo;

    @FindBy(name = "homeLanguage")
    private WebElement slctHomeLanguage;

    @FindBy(name = "correspondenceLanguage")
    private WebElement slctCorrespondenceLanguage;

    @FindBy(name = "physicalAddressCountry")
    private WebElement slctPhysicalAddressCountry;

    @FindBy(name = "residentialAddressLine1")
    private WebElement txtResidentialAddressLineOne;

    @FindBy(name = "residentialAddressLine2")
    private WebElement txtResidentialAddressLineTwo;

    @FindBy(name = "residentialSuburb")
    private WebElement txtResidentialSuburb;

    @FindBy(name = "residentialCity")
    private WebElement txtResidentialCity;

    @FindBy(name = "residentialPostalCode")
    private WebElement txtResidentialPostalCode;

    @FindBy(xpath = "//input[@name = \"addressCheck\" and @value = \"Y\"]")
    private WebElement chkResidentialSameAsPostYes;

    @FindBy(xpath = "//input[@name = \"addressCheck\" and @value = \"N\"]")
    private WebElement chkResidentialSameAsPostNo;

    @FindBy(name = "currentAddressSince")
    private WebElement txtCurrentAddressSince;

    @FindBy(name = "residentialStatus")
    private WebElement slctResidentialStatus;

    @FindBy(name = "employmentSector")
    private WebElement slctEmploymentSector;

    @FindBy(xpath = "//input[@name = \"absaStaff\" and @value = \"Y\"]")
    private WebElement chkAbsaStaffYes;

    @FindBy(xpath = "//input[@name = \"absaStaff\" and @value = \"N\"]")
    private WebElement chkAbsaStaffNo;

    @FindBy(name = "nameOfEmployer")
    private WebElement txtNameOfEmployeer;

    @FindBy(name = "presentEmployment")
    private WebElement selectPresentEmployment;

    @FindBy(xpath = "//input[@name = \"socialGrant\" and @value = \"Y\"]")
    private WebElement chkSocialGrantYes;

    @FindBy(xpath = "//input[@name = \"socialGrant\" and @value = \"N\"]")
    private WebElement chkSocialGrantNo;

    @FindBy(name = "employerAddressCountry")
    private WebElement slctEmployerAddressCountry;

    @FindBy(name = "employerAddressLine1")
    private WebElement txtEmployerAddressLineOne;

    @FindBy(name = "employerSuburb")
    private WebElement txtEmployerSuburb;

    @FindBy(name = "employerCity")
    private WebElement txtEmployerCity;

    @FindBy(name = "employerPostalCode")
    private WebElement txtEmployerPostalCode;

    @FindBy(name = "employmentSince")
    private WebElement txtCurrentEmploymentSince;

    @FindBy(xpath = "//input[@name = \"housingScheme\" and @value = \"Y\"]")
    private WebElement chkHousingSchemeYes;

    @FindBy(xpath = "//input[@name = \"housingScheme\" and @value = \"N\"]")
    private WebElement chkHousingSchemeNo;

    @FindBy(xpath = "(//td[. = \"Total monthly gross income (before deductions)\"]//following-sibling::td//a/img)[1]")
    private WebElement icnTotalMonthlyGrossIncome;

    @FindBy(xpath = "(//td[. =\"Total deductions \"]//following-sibling::td//a//img)[1]")
    private WebElement icnTotalDeductions;

    @FindBy(xpath = "(//td[. =\"Total monthly fixed debt repayments \"]//following-sibling::td//a//img)[1]")
    private WebElement icnTotalMonthlyFixedDebtRepayments;

    @FindBy(xpath = "(//td[. = \"Total monthly living expenses \"]//following-sibling::td//a/img)[1]")
    private WebElement icnTotalMonthlyLivingExpenses;

    @FindBy(name = "monthlyIncome")
    private WebElement txtMonthlyIncome;

    @FindBy(name = "commission")
    private WebElement txtCommission;

    @FindBy(name = "tax")
    private WebElement txtTax;


    @FindBy(name = "uif")
    private WebElement txtUif;


    @FindBy(name = "pension")
    private WebElement txtPension;


    @FindBy(name = "medicalAid")
    private WebElement txtMedicalAid;

    @FindBy(name = "currHomeInstalRent")
    private WebElement txtCurrentHomeInstallment;

    @FindBy(name = "currHomeInstalRentCancel")
    private WebElement txtCurrentHomeInstallmentRentCancel;

    @FindBy(name = "assetFinLeasePayment")
    private WebElement txtAssetVehiclePayments;

    @FindBy(name = "loanOverdraft")
    private WebElement txtLoanOverdraft;

    @FindBy(name = "creditCardPayments")
    private WebElement txtCreditCardPayments;

    @FindBy(name = "retailAcc")
    private WebElement txtRetailAccounts;

    @FindBy(name = "otherDebt")
    private WebElement txtOtherDebts;

    @FindBy(xpath = "//input[@name = \"creditCard\" and @value = \"Y\"]")
    private WebElement chkCreditCardYes;

    @FindBy(xpath = "//input[@name = \"creditCard\" and @value = \"N\"]")
    private WebElement chkCreditCardNo;

    @FindBy(xpath = "//select[@name = \"accountType\"]")
    private WebElement slctSalaryDeposited;

    @FindBy(xpath = "//select[@name = \"nameOfInstitution\"]")
    private WebElement slctInstitutionName;

    @FindBy(xpath = "//input[@name = \"accountNumber\"]")
    private WebElement txtAccountNumber;

    @FindBy(xpath = "//input[@name = \"anotherIncomeAccount\" and @value = \"Y\"]")
    private WebElement chkOtherIncomeYes;

    @FindBy(xpath = "//input[@name = \"anotherIncomeAccount\" and @value = \"N\"]")
    private WebElement chkOtherIncomeNo;

    @FindBy(xpath = "//input[@name = \"deaConsent\" and @value = \"Y\"]")
    private WebElement chkConsentToRequestStatementsYes;

    @FindBy(xpath = "//input[@name = \"deaConsent\" and @value = \"N\"]")
    private WebElement chkConsentToRequestStatementsNo;

    @FindBy(xpath = "//input[@name = \"nonAbsaCheque\" and @value = \"Y\"]")
    private WebElement chkChequeAccountYes;

    @FindBy(xpath = "//input[@name = \"nonAbsaCheque\" and @value = \"N\"]")
    private WebElement chkChequeAccountNo;

    @FindBy(xpath = "//input[@name = \"existingHLSettled\" and @value = \"Y\"]")
    private WebElement chkExistingHLSettledYes;

    @FindBy(xpath = "//input[@name = \"existingHLSettled\" and @value = \"N\"]")
    private WebElement chkExistingHLSettledNo;

    @FindBy(xpath = "//input[@name = \"debtCounselling\" and @value = \"Y\"]")
    private WebElement chkDebtCounsellingYes;

    @FindBy(xpath = "//input[@name = \"debtCounselling\" and @value = \"N\"]")
    private WebElement chkDebtCounsellingNo;

    @FindBy(xpath = "//input[@name = \"declaredInsolvent\" and @value = \"Y\"]")
    private WebElement chkDeclaredInsolventYes;

    @FindBy(xpath = "//input[@name = \"declaredInsolvent\" and @value = \"N\"]")
    private WebElement chkDeclaredInsolventNo;

    @FindBy(name = "groceries")
    private WebElement txtGroceries;

    @FindBy(name = "main")
    private WebElement frameMain;


    public void selectPreferredCommunicationChannel(String preferredChannel) {
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        baseClass.selectOptionByText(slctPreferredCommChannel, preferredChannel);
    }


    public void captureCellNumber(String cellNumber) {
        baseClass.captureText(cellNumber, txtCellNumber);
    }

    public void captureEmailAddress(String emailAddress) {
        baseClass.captureText(emailAddress, txtEmailAddress);
    }

    public void captureSurname(String surname) {
        baseClass.captureText(surname, txtSurname);
    }

    public void captureFullNames(String fullNames) {
        baseClass.captureText(fullNames, txtFullNames);
    }

    public void selectIDType(String idType) {
        baseClass.selectOptionByText(slctIDType, idType);
    }

    public void captureIDNUmber(String idNumber) {
        baseClass.captureText(idNumber, txtIDNumber);
    }

    public void selectEmploymentStatus(String employmentStatus) {
        baseClass.selectOptionByText(slctEmploymentStatus, employmentStatus);
    }

    public void clickIncomeBracketTwo() {
        baseClass.clickObject(chkIncomeBracketTwo);
    }

    public void selectMaritalStatus(String maritalStatus) {
        baseClass.selectOptionByText(slctMaritalStatus, maritalStatus);
    }

    public void clickContinue() {
        baseClass.clickObject(btnContinue);
    }

    public void clickParticipantToComplete() {
        baseClass.clickObject(chkParticipantInput);
    }

    public void clickComplete() {
        baseClass.clickObject(btnComplete);
    }

    public void selectTitle(String salutation) {
        baseClass.selectOptionByText(slctTitle, salutation);
    }

    public void selectCountryOfBirth(String countryOfBirth) {
        baseClass.selectOptionByText(slctCountyOfBirth, countryOfBirth);
    }

    public void selectSalaryDepositedAccountType(String accountType) {
        baseClass.selectOptionByText(slctSalaryDeposited, accountType);
    }

    public void selectBankInstitutionName(String bank) {
        baseClass.selectOptionByText(slctInstitutionName, bank);
    }

    public void captureAccountNumber(String accountNumber){
        baseClass.captureText(accountNumber, txtAccountNumber);
    }

    public void selectNationality(String nationality) {
        baseClass.selectOptionByText(slctNationality, nationality);
    }

    public void selectRace(String race) {
        baseClass.selectOptionByText(slctRace, race);
    }

    public void clickPostMatricQualificationYesOrNo(boolean postMarticQualificationOption) {
        WebElement element = null;
        if (postMarticQualificationOption) {
            element = chkPostMatricQualificationYes;
        } else {
            element = chkPostMatricQualificationNo;
        }
        baseClass.clickObject(element);
    }


    public void selectHomeLanguage(String language) {
        baseClass.selectOptionByText(slctHomeLanguage, language);
    }

    public void selectCorrespondenceLanguage(String language) {
        baseClass.selectOptionByText(slctCorrespondenceLanguage, language);
    }

    public void selectPhysicalAddressCountry(String country) {
        baseClass.selectOptionByText(slctPhysicalAddressCountry, country);
    }

    private void capturePhysicalAddressLineOne(String addressLineOne) {
        baseClass.captureText(addressLineOne, txtResidentialAddressLineOne);
    }

    private void capturePhysicalAddressLineTwo(String addressLineTwo) {
        baseClass.captureText(addressLineTwo, txtResidentialAddressLineTwo);
    }

    private void capturePhysicalAddressSuburb(String physicalAddressSuburb) {
        baseClass.captureText(physicalAddressSuburb, txtResidentialSuburb);
    }

    private void capturePhysicalAddressResidentialCity(String physicalAddressResidentialCity) {
        baseClass.captureText(physicalAddressResidentialCity, txtResidentialCity);
    }

    private void capturePhysicalAddressPostalCode(String physicalAddressPostalCode) {
        baseClass.captureText(physicalAddressPostalCode, txtResidentialPostalCode);
    }

    public void captureAddress(String lineOne, String lineTwo, String suburb, String city, String postalCode) {
        capturePhysicalAddressLineOne(lineOne);
        capturePhysicalAddressLineTwo(lineTwo);
        capturePhysicalAddressSuburb(suburb);
        capturePhysicalAddressResidentialCity(city);
        capturePhysicalAddressPostalCode(postalCode);
    }


    public void clickResidentialSameAsPostYesOrNo(boolean residentialSameAsPostOption) {
        WebElement element = null;
        if (residentialSameAsPostOption) {
            element = chkResidentialSameAsPostYes;
        } else {
            element = chkResidentialSameAsPostNo;
        }
        baseClass.clickObject(element);
    }

    public void captureCurrentAddressSince(String currentAddressSince) {
        baseClass.captureText(currentAddressSince, txtCurrentAddressSince);
    }

    public void selectResidentialStatus(String residentialStatus) {
        baseClass.selectOptionByText(slctResidentialStatus, residentialStatus);
    }

    public void selectEmploymentIndustry(String employmentIndustry) {
        baseClass.selectOptionByText(slctEmploymentSector, employmentIndustry);
    }

    public void clickABSAStaffYesOrNo(boolean absaStaffOption) {
        WebElement element = null;
        if (absaStaffOption) {
            element = chkAbsaStaffYes;
        } else {
            element = chkAbsaStaffNo;
        }
        baseClass.clickObject(element);
    }

    public void captureEmployerName(String employerName) {
        baseClass.captureText(employerName, txtNameOfEmployeer);
    }

    public void selectPresentOccupation(String presentOccupation) {
        baseClass.selectOptionByText(selectPresentEmployment, presentOccupation);
    }

    public void clickSocialGrantYesOrNo(boolean socialGrantOption) {
        WebElement element = null;
        if (socialGrantOption) {
            element = chkSocialGrantYes;
        } else {
            element = chkSocialGrantNo;
        }
        baseClass.clickObject(element);
    }

    public void selectEmployerAddressCountry(String country) {
        baseClass.selectOptionByText(slctEmployerAddressCountry, country);
    }

    private void captureEmployerAddressLineOne(String addressLineOne) {
        baseClass.captureText(addressLineOne, txtEmployerAddressLineOne);
    }


    private void captureEmployerAddressSuburb(String employerAddressSuburb) {
        baseClass.captureText(employerAddressSuburb, txtEmployerSuburb);
    }

    private void captureEmployerAddressCity(String employerAddressCity) {
        baseClass.captureText(employerAddressCity, txtEmployerCity);
    }

    private void captureEmployerAddressPostalCode(String employerAddressPostalCode) {
        baseClass.captureText(employerAddressPostalCode, txtEmployerPostalCode);
    }

    public void captureEmployerAddress(String lineOne, String suburb, String city, String postalCode) {
        captureEmployerAddressLineOne(lineOne);
        captureEmployerAddressSuburb(suburb);
        captureEmployerAddressCity(city);
        captureEmployerAddressPostalCode(postalCode);
    }

    public void captureCurrentEmploymentSinceDate(String startDate) {
        baseClass.captureText(startDate, txtCurrentEmploymentSince);
    }

    public void clickHousingSchemeYesOrNo(boolean housingSchemeOption) {
        WebElement element = null;
        if (housingSchemeOption) {
            element = chkHousingSchemeYes;
        } else {
            element = chkHousingSchemeNo;
        }
        baseClass.clickObject(element);
    }

    private void clickMonthlyIncomeIcon() {
        baseClass.clickObject(icnTotalMonthlyGrossIncome);
    }

    private void captureMonthlyIncome(String monthlyIncome) {
        baseClass.captureText(monthlyIncome, txtMonthlyIncome);
    }

    private void captureCommission(String commission) {
        baseClass.captureText(commission, txtCommission);
    }

    public void captureTotalMonthlyIncome(String monthlyIncome, String commission) {

        String windowOne = baseClass.getWindowHandle();
        clickMonthlyIncomeIcon();
        for (String winHandle : baseClass.getWindowHandles()) {
            baseClass.switchWindow(winHandle);
        }
        captureMonthlyIncome(monthlyIncome);
        captureCommission(commission);
        clickContinue();
        baseClass.switchWindow(windowOne);
    }

    private void clickTotalDeductionsIcon() {
        baseClass.clickObject(icnTotalDeductions);
    }

    private void captureTax(String tax) {
        baseClass.captureText(tax, txtTax);
    }

    private void captureUif(String uif) {
        baseClass.captureText(uif, txtUif);
    }

    private void capturePension(String pension) {
        baseClass.captureText(pension, txtPension);
    }

    private void captureMedicalAid(String medicalAid) {
        baseClass.captureText(medicalAid, txtMedicalAid);
    }

    public void captureTotalDeductions(String tax, String uif, String pension, String medicalAid) {

        String windowOne = baseClass.getWindowHandle();
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        clickTotalDeductionsIcon();
        for (String winHandle : baseClass.getWindowHandles()) {
            baseClass.switchWindow(winHandle);
        }
        captureTax(tax);
        captureUif(uif);
        capturePension(pension);
        captureMedicalAid(medicalAid);
        clickContinue();
        baseClass.switchWindow(windowOne);
    }


    private void clickTotalMonthlyFixedDebtRepaymentsIcon() {
        baseClass.clickObject(icnTotalMonthlyFixedDebtRepayments);
    }

    private void captureTotalMonthlyHomeLoanRepayments(String totalMonthlyHomeLoanRepayments){
        baseClass.captureText(totalMonthlyHomeLoanRepayments, txtCurrentHomeInstallment);
    }
    private void captureAmountHomeloanRepaymentsThatWillStop(String loanToBeStopped){
        baseClass.captureText(loanToBeStopped, txtCurrentHomeInstallmentRentCancel);
    }

    private void captureAssetFinanceVehicleRepayments(String assetFinanceVehicleRepayments){
        baseClass.captureText(assetFinanceVehicleRepayments, txtAssetVehiclePayments);
    }

    private void captureLoanOverdraftRepayments(String loanOverdraftRepayments){
        baseClass.captureText(loanOverdraftRepayments, txtLoanOverdraft);
    }

    private void captureCreditCardPayments(String creditCardPayments){
        baseClass.captureText(creditCardPayments, txtCreditCardPayments);
    }

    private void captureRetailAccountPayments(String retailAccountPayments){
        baseClass.captureText(retailAccountPayments, txtRetailAccounts);
    }

    private void captureOtherFixedDebtRepayment(String otherFixedDebtRepayments){
        baseClass.captureText(otherFixedDebtRepayments, txtOtherDebts);
    }

    public void captureTotalMonthlyFixedDebtRepayments(String totalMonthlyHomeLoanRepayments, String loanToBeStopped, String assetFinanceVehicleRepayments, String loanOverdraftRepayments, String creditCardPayments, String retailAccountPayments, String otherFixedDebtRepayments){
        String windowOne = baseClass.getWindowHandle();
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        clickTotalMonthlyFixedDebtRepaymentsIcon();
        for (String winHandle : baseClass.getWindowHandles()) {
            baseClass.switchWindow(winHandle);
        }
        captureTotalMonthlyHomeLoanRepayments(totalMonthlyHomeLoanRepayments);
        //captureAmountHomeloanRepaymentsThatWillStop(loanToBeStopped);
        captureAssetFinanceVehicleRepayments(assetFinanceVehicleRepayments);
        captureLoanOverdraftRepayments(loanOverdraftRepayments);
        captureCreditCardPayments(creditCardPayments);
        captureRetailAccountPayments(retailAccountPayments);
        captureOtherFixedDebtRepayment(otherFixedDebtRepayments);
        clickContinue();
        baseClass.switchWindow(windowOne);
    }

    private void clickTotalMonthlyLivingExpenses(){
        baseClass.clickObject(icnTotalMonthlyLivingExpenses);
    }

    private void captureGroceriesLivingExpense(String groceriesExpense){
        baseClass.captureText(groceriesExpense, txtGroceries);
    }

    public void captureTotalMonthlyLivingExpenses(String groceriesExpense){
        String windowOne = baseClass.getWindowHandle();
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        clickTotalMonthlyLivingExpenses();
        for (String winHandle : baseClass.getWindowHandles()) {
            baseClass.switchWindow(winHandle);
        }
        captureGroceriesLivingExpense(groceriesExpense);
        clickContinue();
        baseClass.switchWindow(windowOne);
    }

    public void clickCreditCardYesOrNo(boolean creditCard) {
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        WebElement element = null;
        if (creditCard) {
            element = chkCreditCardYes;
        } else {
            element = chkCreditCardNo;
        }
        baseClass.clickObject(element);
    }

    public void clickOtherIncomePaidInAnotherAccountYesOrNo(boolean chequeAccountOption) {
        WebElement element = null;
        if (chequeAccountOption) {
            element = chkOtherIncomeYes;
        } else {
            element = chkOtherIncomeNo;
        }
        baseClass.clickObject(element);
    }

    public void clickChequeYesOrNo(boolean chequeAccountOption) {
        WebElement element = null;
        if (chequeAccountOption) {
            element = chkChequeAccountYes;
        } else {
            element = chkChequeAccountNo;
        }
        baseClass.clickObject(element);
    }

    public void clickConsentToRequestStatements(boolean consent) {
        WebElement element = null;
        if (consent) {
            element = chkConsentToRequestStatementsYes;
        } else {
            element = chkConsentToRequestStatementsNo;
        }
        baseClass.clickObject(element);
    }

    public void clickExistingHLToBeCancelledYesOrNo(boolean existingHomeLoanCancelledOption) {
        WebElement element = null;
        if (existingHomeLoanCancelledOption) {
            element = chkExistingHLSettledYes;
        } else {
            element = chkExistingHLSettledNo;
        }
        baseClass.clickObject(element);
    }

    public void clickUnderDebtCounsellingYesOrNo(boolean debtCounsellingOption) {
        WebElement element = null;
        if (debtCounsellingOption) {
            element = chkDebtCounsellingYes;
        } else {
            element = chkDebtCounsellingNo;
        }
        baseClass.clickObject(element);
    }

    public void clickDeclaredInsolventYesOrNo(boolean declaredInsolvent) {
        WebElement element = null;
        if (declaredInsolvent) {
            element = chkDeclaredInsolventYes;
        } else {
            element = chkDeclaredInsolventNo;
        }
        baseClass.clickObject(element);
    }



}
