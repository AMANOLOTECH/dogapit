package za.co.absa.webPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import za.co.absa.Base.BaseClass;

public class HomeLoansBuyAHomeLoanDetailsPage {
    WebDriver driver;
    BaseClass baseClass;

    public HomeLoansBuyAHomeLoanDetailsPage(WebDriver driver) {
        this.driver = driver;
        baseClass = new BaseClass(this.driver);
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(name = "bondRegistrationAmount")
    private WebElement txtBondRegistrationAmount;

    @FindBy(name = "dateOfPurchase")
    private WebElement txtDateOfPurchase;

    @FindBy(name = "repaymentDay")
    private WebElement slctRepaymentDay;

    @FindBy(xpath = "//input[@name = \"multiPlan\" and @value = \"Y\"]")
    private WebElement chkMultiPlanYes;

    @FindBy(xpath = "//input[@name = \"multiPlan\" and @value = \"N\"]")
    private WebElement chkMultiPlanNo;

    @FindBy(name = "termOfLoan")
    private WebElement sltTermOfLoan;

    @FindBy(name = "multiPlan1TermOfLoan")
    private WebElement sltTermOfMultiPlan;

    @FindBy(name = "multiPlan1AccountName")
    private WebElement txtMultiplanName;

    @FindBy(name = "multiPlan1LoanAmount")
    private WebElement txtMultiplanLoanAmount;

    @FindBy(name = "valuationContactName")
    private WebElement txtValuationContactName;

    @FindBy(name = "valuationContactCellNumber")
    private WebElement txtValuationContactNumber;

    @FindBy(xpath = "//input[@name=\"button_processMaintainLoanDetails\"]")
    private WebElement btnContinue;

    @FindBy(name = "main")
    private WebElement frameMain;

    public void captureBondRegistrationAmount(String bondRegistrationAmount){
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        baseClass.captureText(bondRegistrationAmount, txtBondRegistrationAmount);
    }

    public void captureDateOfPurchase(String dateOfPurchase){
        baseClass.captureText(dateOfPurchase, txtDateOfPurchase);
    }

    public void selectRepaymentDay(String repaymentDay){
        baseClass.selectOptionByText(slctRepaymentDay, repaymentDay);
    }


    public void clickMultiPlanYesOrNo(boolean multiPlanOption){
        WebElement element = null;

        if (multiPlanOption){
            element = chkMultiPlanYes;
        }else{
            element = chkMultiPlanNo;
        }

        baseClass.clickObject(element);
    }

    public void selectTermOfLoan(String term){
        baseClass.selectOptionByText(sltTermOfLoan,term);
    }

    public void selectTermOfMultiplanLoan(String term){
        baseClass.selectOptionByText(sltTermOfMultiPlan,term);
    }

    public void captureMultiplanName(String multiplanName){
        baseClass.captureText(multiplanName, txtMultiplanName);
    }

    public void captureMultiplanLoanAmount(String loanAmount){
        baseClass.captureText(loanAmount, txtMultiplanLoanAmount);
    }

    public void captureValuationName(String loanAmount){
        baseClass.captureText(loanAmount, txtValuationContactName);
    }

    public void captureValuationContactNumber(String loanAmount){
        baseClass.captureText(loanAmount, txtValuationContactNumber);
    }

    public void clickContinue(){
        baseClass.clickObject(btnContinue);
    }





}
