package za.co.absa.utils;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

public class HomeLoansFileWriter {
    private static final String CHARACTER_ENCODING = "UTF-8";

        public HomeLoansFileWriter(){
            //intentionally left blank
        }

        public void applicationNumberWriter(String applicationNumber){
            String logger;
            try {
                PrintWriter writer = new PrintWriter("src/test/resources/testData/applicationNumber.properties",
                        CHARACTER_ENCODING);
                logger = "applicationNumber = " + applicationNumber;
                writer.println(logger);
                writer.close();
            }catch (UnsupportedEncodingException | FileNotFoundException e){
                e.printStackTrace();
            }
        }
}
