package za.co.absa.webPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import za.co.absa.Base.BaseClass;
import za.co.absa.utils.HomeLoansFileWriter;

public class HomeLoansBuyAHomePage {
    WebDriver driver;
    BaseClass baseClass;
    HomeLoansFileWriter homeLoansFileWriter;

    public HomeLoansBuyAHomePage(WebDriver driver) {
        this.driver = driver;
        baseClass = new BaseClass(this.driver);
        homeLoansFileWriter = new HomeLoansFileWriter();
        PageFactory.initElements(this.driver, this);
    }


    @FindBy(xpath = "//input[@value=\"Continue\" and @type=\"submit\"]")
    private WebElement btnContinue;

    @FindBy(xpath = " //select[@name=\"clientGroup\"]")
    private WebElement slctTypeOfApplication;

    @FindBy(xpath = "//tr[@id=\"reApplication_INPUT\"]//input[@value = \"Y\"]")
    private WebElement chkReApplicationYes;

    @FindBy(xpath = "//tr[@id=\"reApplication_INPUT\"]//input[@value = \"N\"]")
    private WebElement chkReApplicationNo;

    @FindBy(xpath = "//tr[@id=\"receivedDip_INPUT\"]//input[@value = \"Y\"]")
    private WebElement chkReceivedEstimatorFromABSAYes;

    @FindBy(xpath = "//tr[@id=\"receivedDip_INPUT\"]//input[@value = \"N\"]")
    private WebElement chkReceivedEstimatorFromABSANo;

    @FindBy(xpath = "//tr[@id=\"propertyTypeIndicator_INPUT\"]//input[@value = \"Y\"]")
    private WebElement chkCommercialPropertyYes;

    @FindBy(xpath = "//tr[@id=\"propertyTypeIndicator_INPUT\"]//input[@value = \"N\"]")
    private WebElement chkCommercialPropertyNo;

    @FindBy(xpath = "//select[@name=\"residentialPropertyType\"]")
    private WebElement slctResidentialPropertyType;

    @FindBy(xpath = "//select[@name=\"occupiedBy\"]")
    private WebElement slctOccupiedBy;

    @FindBy(xpath = "(//td[contains(., \"Do you want a quote for life insurance?\")])[2]//following-sibling::td//input[@value = \"Y\"]")
    private WebElement chkLifeInsuranceQuoteYes;

    @FindBy(xpath = "//td[contains(., \"Application number: \")]")
    private WebElement lblApplicationNumber;


    @FindBy(xpath = "(//td[contains(., \"Do you want a quote for life insurance?\")])[2]//following-sibling::td//input[@value = \"N\"]")
    private WebElement chkLifeInsuranceQuoteNo;

    @FindBy(xpath = "(//td[contains(., \"Do you want a quote on Absa property insurance?\")])[2]//following-sibling::td//input[@value = \"Y\"]")
    private WebElement chkABSAPropertyInsuranceYes;

    @FindBy(xpath = "(//td[contains(., \"Do you want a quote on Absa property insurance?\")])[2]//following-sibling::td//input[@value = \"N\"]")
    private WebElement chkABSAPropertyInsuranceNo;


    @FindBy(xpath = "(//td[contains(., \"Would you like an Absa consultant to contact you with regards to a will?\")])[2]//following-sibling::td//input[@value = \"Y\"]")
    private WebElement chkConsultantCallYes;

    @FindBy(xpath = "(//td[contains(., \"Would you like an Absa consultant to contact you with regards to a will?\")])[2]//following-sibling::td//input[@value = \"N\"]")
    private WebElement chkConsultantCallNo;

    @FindBy(name = "existingAccountNo")
    private WebElement txtExistingAccountNumber;

    @FindBy(xpath = "//tr[@id=\"furtherAdvance_INPUT\"]//input[@value = \"Y\"]")
    private WebElement chkSuretyAvailableYes;

    @FindBy(xpath = "//tr[@id=\"furtherAdvance_INPUT\"]//input[@value = \"N\"]")
    private WebElement chkSuretyAvailableNo;

    @FindBy(xpath = "//tr[@id=\"debtConsolidationInd_INPUT\"]//input[@value = \"Y\"]")
    private WebElement chkDebtConsolidationYes;

    @FindBy(xpath = "//tr[@id=\"debtConsolidationInd_INPUT\"]//input[@value = \"N\"]")
    private WebElement chkDebtConsolidationNo;

    @FindBy(xpath = "//select[@name=\"debtOption\"]")
    private WebElement slctDebtOption;

    @FindBy(xpath = "//input[@name=\"grossMonthlyIncome\"]")
    private WebElement txtGrossMonthlyIncome;

    @FindBy(xpath = "//input[@name=\"purchasePrice\"]")
    private WebElement txtPurchasePrice;

    @FindBy(xpath = "//input[@name=\"loanAmountRequired\"]")
    private WebElement txtLoanAmountRequired;

    @FindBy(xpath = "//tr[@id=\"applicantIndicator_INPUT\"]//input[@value = \"Y\"]")
    private WebElement chkAreYouApplicantYes;

    @FindBy(xpath = "//input[@name=\"creditCheckConsent\" and @value = \"Y\"]")
    private WebElement chkCreditCheckConsentYes;

    @FindBy(xpath = "//input[@name=\"creditCheckConsent\" and @value = \"N\"]")
    private WebElement chkCreditCheckConsentNo;


    @FindBy(xpath = "//tr[@id=\"applicantIndicator_INPUT\"]//input[@value = \"N\"]")
    private WebElement chkAreYouApplicantNo;

    @FindBy(xpath = "//select[@name=\"originatorType\"]")
    private WebElement slctMainSourceOfOrigination;

    @FindBy(xpath = "//input[@name=\"preferredBranchName\"]")
    private WebElement txtPreferredBranchName;

    @FindBy(xpath = "//input[@name=\"button_promptSearchPreferredBranch\"]")
    private WebElement btnSearchPreferredBranch;

    @FindBy(xpath = "//a[contains(., \"RANDBURG\")]")
    private WebElement lnkMidrand;

    @FindBy(xpath = "//input[@name=\"button_processMaintainApplicationDetails\"]")
    private WebElement btnGettingStartedContinue;

    @FindBy(name = "main")
    private WebElement frameMain;

    public void selectTypeOfApplication(String typeOfApplication) {
        baseClass.selectOptionByText(slctTypeOfApplication, typeOfApplication);
    }


    public void clickReceivedEstimatorFromABSAYesOrNo(boolean reApplicationIndicator) {
        WebElement element = null;
        if (reApplicationIndicator) {
            element = chkReceivedEstimatorFromABSAYes;
        } else {
            element = chkReceivedEstimatorFromABSANo;
        }
        baseClass.clickObject(element);
    }

    public void clickReApplicationYesOrNo(boolean reApplicationIndicator) {
        WebElement element = null;
        if (reApplicationIndicator) {
            element = chkReApplicationYes;
        } else {
            element = chkReApplicationNo;
        }
        baseClass.clickObject(element);
    }

    public void clickCommercialPropertyYesOrNo(boolean propertyTypeIndicator) {
        WebElement element = null;
        if (propertyTypeIndicator) {
            element = chkCommercialPropertyYes;
        } else {
            element = chkCommercialPropertyNo;
        }
        baseClass.clickObject(element);
    }

    public void selectResidentialPropertyType(String propertyType) {
        baseClass.selectOptionByText(slctResidentialPropertyType, propertyType);
    }

    public void selectOccupiedBy(String propertyType) {
        baseClass.selectOptionByText(slctOccupiedBy, propertyType);
    }

    public void clickLifeInsuranceQuoteYesOrNo(boolean lifeInsuranceOption) {
        WebElement element = null;
        if (lifeInsuranceOption) {
            element = chkLifeInsuranceQuoteYes;
        } else {
            element = chkLifeInsuranceQuoteNo;
        }
        baseClass.clickObject(element);
    }

    public void clickABSAPropertyInsuranceYesOrNo(boolean propertyInsuranceOption) {
        WebElement element = null;
        if (propertyInsuranceOption) {
            element = chkABSAPropertyInsuranceYes;
        } else {
            element = chkABSAPropertyInsuranceNo;
        }
        baseClass.clickObject(element);
    }

    public void clickConsultantCallForWillYesOrNo(boolean consultantCallOption) {
        WebElement element = null;
        if (consultantCallOption) {
            element = chkConsultantCallYes;
        } else {
            element = chkConsultantCallNo;
        }
        baseClass.clickObject(element);
    }

    public void captureExistingAccountNumber(String existingAccNumber){
        baseClass.captureText(existingAccNumber, txtExistingAccountNumber);
    }


    public void clickSuretyAvailableYesOrNo(boolean suretyAvailableOption) {
        WebElement element = null;
        if (suretyAvailableOption) {
            element = chkSuretyAvailableYes;
        } else {
            element = chkSuretyAvailableNo;
        }
        baseClass.clickObject(element);
    }

    public void clickDebtConsolidationYesOrNo(boolean debtConsolidationOption) {
        WebElement element = null;
        if (debtConsolidationOption) {
            element = chkDebtConsolidationYes;
        } else {
            element = chkDebtConsolidationNo;
        }
        baseClass.clickObject(element);
    }


    public void captureLoanAmountRequired(String loanAmountRequired) {
        baseClass.captureText(loanAmountRequired, txtLoanAmountRequired);
    }

    public void capturePurchasePrice(String purchasePrice) {
        baseClass.captureText(purchasePrice, txtPurchasePrice);
    }

    public void captureGrossMonthlyIncome(String grossMonthlyIncome) {
        baseClass.captureText(grossMonthlyIncome, txtGrossMonthlyIncome);
    }

    public void selectDebtConsolidationOption(String debtOption) {
        baseClass.selectOptionByText(slctDebtOption, debtOption);
    }

    public void clickAreYouApplicantYesOrNo(boolean debtConsolidationOption) {
        WebElement element = null;
        if (debtConsolidationOption) {
            element = chkAreYouApplicantYes;
        } else {
            element = chkAreYouApplicantNo;
        }
        baseClass.clickObject(element);
    }

    public void clickCreditCheckConsentYesOrNo(boolean creditCheckConsent) {
        WebElement element = null;
        if (creditCheckConsent) {
            element = chkCreditCheckConsentYes;
        } else {
            element = chkCreditCheckConsentNo;
        }
        baseClass.clickObject(element);
    }


    public void selectMainSourceOfOrigination(String sourceOfOrigination) {
        baseClass.selectOptionByText(slctMainSourceOfOrigination, sourceOfOrigination);
    }


    public void capturePreferedBranch(String preferedBranch) {
        baseClass.captureText(preferedBranch, txtPreferredBranchName);
    }

    public void clickSearchPreferedBranch() {
        baseClass.clickObject(btnSearchPreferredBranch);
    }


    public void clickPreferedBranchResult() {
        baseClass.clickObject(lnkMidrand);
    }

    public void clickGettingStartedContinue() {

        baseClass.clickObject(btnGettingStartedContinue);
    }

    public void writeApplicationNumber(){
        String applicationNumber = baseClass.getText(lblApplicationNumber).substring(20);
        System.out.println(applicationNumber);
        homeLoansFileWriter.applicationNumberWriter(applicationNumber);
    }

    public String getApplicationNumber(){
        return baseClass.getText(lblApplicationNumber).substring(20);
    }

    public void clickContinue() {
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        baseClass.clickObject(btnContinue);
    }
}
