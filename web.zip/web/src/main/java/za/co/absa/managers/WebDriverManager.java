package za.co.absa.managers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import za.co.absa.customexceptions.ConfigurationKeyNotMatchedException;
import za.co.absa.enums.DriverType;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class WebDriverManager {
    private WebDriver driver;
    private static final String CHROME_DRIVER_PROPERTY = "webdriver.chrome.driver";
    private static final String IE_DRIVER_PROPERTY = "webdriver.ie.driver";
    private static final String FIREFOX_DRIVER_PROPERTY = "webdriver.gecko.driver";
    private static final String EDGE_DRIVER_PROPERTY = "webdriver.edge.driver";

    public WebDriverManager() {
        //Intentionally left blank
    }

    public WebDriver createDriver() throws IOException, ConfigurationKeyNotMatchedException {
        DriverType driverType = FileReaderManager.getInstance().getConfigReader().getDriverType();

        switch (driverType) {
            case EDGE:
                System.setProperty(EDGE_DRIVER_PROPERTY, FileReaderManager.getInstance().getConfigReader().getEdgeDriverPath());
                driver = new EdgeDriver();
                break;
            case CHROME:
                System.setProperty(CHROME_DRIVER_PROPERTY, FileReaderManager.getInstance().getConfigReader().getChromeDriverPath());
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.setExperimentalOption("useAutomationExtension", false);
                chromeOptions.setHeadless(false);
                driver = new ChromeDriver(chromeOptions);
                break;
            case FIREFOX:
                System.setProperty(FIREFOX_DRIVER_PROPERTY, FileReaderManager.getInstance().getConfigReader().getFirefoxDriverPath());
                driver = new FirefoxDriver();
                break;
            case INTERNETEXPLORER:
                System.setProperty(IE_DRIVER_PROPERTY, FileReaderManager.getInstance().getConfigReader().getInternetExplorerDriverPath());
                driver = new InternetExplorerDriver();
                break;

        }

        if (Boolean.TRUE.equals(FileReaderManager.getInstance().getConfigReader().getMaximizeWindowSize()))
            driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(FileReaderManager.getInstance().getConfigReader().getImplicitlyWait(), TimeUnit.SECONDS);
        return driver;
    }

}
