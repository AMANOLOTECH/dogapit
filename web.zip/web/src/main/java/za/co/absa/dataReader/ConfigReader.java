package za.co.absa.dataReader;

import org.junit.Test;
import za.co.absa.customexceptions.ConfigurationKeyNotMatchedException;
import za.co.absa.customexceptions.UrlNotFoundException;
import za.co.absa.enums.DriverType;
import za.co.absa.enums.EnvironmentType;

import java.io.*;
import java.util.Properties;

import static za.co.absa.enums.EnvironmentType.ETE;
import static za.co.absa.enums.EnvironmentType.QA;

public class ConfigReader {
    private final Properties properties;
    private static final String PROPERTY_FILE_PATH = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testData" + File.separator + "Configuration.properties";
    private static final String PROPERTY_ERROR_MESSAGE = "driverPath not defined in the Configuration.properties file";

    public ConfigReader() throws IOException{
        try(BufferedReader reader = new BufferedReader(new FileReader(PROPERTY_FILE_PATH))) {
            properties = new Properties();
            propertyReader(properties, reader);
        }catch (FileNotFoundException e){
            e.printStackTrace();
            throw new FileNotFoundException("Configuration.properties not found at " + PROPERTY_FILE_PATH);
        }
    }

    private void propertyReader(Properties properties, BufferedReader reader){
        try {
            properties.load(reader);
            reader.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public EnvironmentType getEnvironmentType() throws ConfigurationKeyNotMatchedException {
        String environment = properties.getProperty("environment");
        if (environment == null || environment.equalsIgnoreCase("qa")) return QA;
        else if(environment.equalsIgnoreCase("ete")) return EnvironmentType.ETE;
        else throw new ConfigurationKeyNotMatchedException("Environment Type Key value in Configuration.properties is not matched: " + environment);
    }

    public String getUrl() throws IOException, UrlNotFoundException, ConfigurationKeyNotMatchedException{
        String url = "";
        if (getEnvironmentType().equals(QA)){
            url = getQAUrl();
        }else if(getEnvironmentType().equals(ETE)){
            url = getETEUrl();
        }
        return url;
    }

    private String getQAUrl() throws UrlNotFoundException{
        String url = properties.getProperty("qaUrl");
        if(url != null) return url;
        else throw new UrlNotFoundException("Url not specified in the Configurations.properties file");
    }

    private String getETEUrl() throws UrlNotFoundException{
        String url = properties.getProperty("eteUrl");
        if(url != null) return url;
        else throw new UrlNotFoundException("Url not specified in the Configurations.properties file");
    }

    public DriverType getDriverType() throws ConfigurationKeyNotMatchedException{
        String browserName = properties.getProperty("browser");
        if (browserName == null || browserName.equalsIgnoreCase("chrome")) return DriverType.CHROME;
        else if (browserName.equalsIgnoreCase("edge")) return DriverType.EDGE;
        else if(browserName.equalsIgnoreCase("firefox")) return DriverType.FIREFOX;
        else if (browserName.equalsIgnoreCase("internetexplorer") || browserName.equalsIgnoreCase("ie")) return DriverType.INTERNETEXPLORER;
        else throw new ConfigurationKeyNotMatchedException("Browser Name Key value in Configuration.properties is not matched: " + browserName);
    }

    public long getImplicitlyWait(){
        String implicitlyWait = properties.getProperty("implicitWait");
        if (implicitlyWait != null){
            try {
                return Long.parseLong(implicitlyWait);
            }catch (NumberFormatException e){
                throw new NumberFormatException("Not able to parse value: " + implicitlyWait + "into long");
            }
        }
        return 30;
    }

    public Boolean getMaximizeWindowSize(){
        String windowSize = properties.getProperty("maximizeWindowSize");
        return Boolean.valueOf(windowSize);
    }

    public String getChromeDriverPath() throws FileNotFoundException{
        String driverPath = properties.getProperty("chromeDriverPath");
        if (driverPath != null) return driverPath;
        else throw new FileNotFoundException(PROPERTY_ERROR_MESSAGE);
    }

    public String getInternetExplorerDriverPath() throws FileNotFoundException{
        String driverPath = properties.getProperty("ieDriverPath");
        if (driverPath != null) return driverPath;
        else throw new FileNotFoundException(PROPERTY_ERROR_MESSAGE);
    }

    public String getFirefoxDriverPath() throws FileNotFoundException{
        String driverPath = properties.getProperty("firefoxDriverPath");
        if (driverPath != null) return driverPath;
        else throw new FileNotFoundException(PROPERTY_ERROR_MESSAGE);
    }

    public String getEdgeDriverPath() throws FileNotFoundException{
        String driverPath = properties.getProperty("edgeDriverPath");
        if (driverPath != null) return driverPath;
        else throw new FileNotFoundException(PROPERTY_ERROR_MESSAGE);
    }

    public String getReportConfigPath(){
        String reportConfigPath = properties.getProperty("reportConfigPath");
        if(reportConfigPath!= null) return reportConfigPath;
        else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
    }





}

