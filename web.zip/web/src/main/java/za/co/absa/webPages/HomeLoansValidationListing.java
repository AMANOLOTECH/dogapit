package za.co.absa.webPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import za.co.absa.Base.BaseClass;

public class HomeLoansValidationListing {
    WebDriver driver;
    BaseClass baseClass;

    public HomeLoansValidationListing(WebDriver driver){
        this.driver = driver;
        baseClass = new BaseClass(this.driver);
        PageFactory.initElements(this.driver, this);
    }

    @FindBy (name = "searchAppNo")
    private WebElement txtSearchApplication;

    @FindBy(name = "button_searchbtn")
    private WebElement btnSearch;

    @FindBy (xpath = "(//input[@name = \"applicationNo\"])[1]")
    private WebElement chkApplicationNumber;

    @FindBy (name = "button_newDevelopment")
    private WebElement btnNewDevelopment;

    @FindBy(name = "main")
    private WebElement frameMain;

    public void captureApplicationNumber(String applicationNumber){
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        baseClass.captureText(applicationNumber, txtSearchApplication);
    }

    public void clickSearch(){
        baseClass.clickObject(btnSearch);
    }

    public void clickApplicationNumberCheck(){
        baseClass.clickObject(chkApplicationNumber);
    }

    public void clickNewDevelopment(){
        baseClass.clickObject(btnNewDevelopment);
    }
}
