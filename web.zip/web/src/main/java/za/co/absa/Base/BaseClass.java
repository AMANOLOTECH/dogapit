package za.co.absa.Base;

import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import za.co.absa.managers.WebDriverManager;
import za.co.absa.utils.PageLoadWaiterClass;
import za.co.absa.utils.ScreenShotCapturer;

import java.util.Set;

public class BaseClass {
    WebDriver driver;
    WebDriverManager webDriverManager;
    ScreenShotCapturer screenShotCapturer;
    String status;

    public BaseClass(WebDriver driver) {
        webDriverManager = new WebDriverManager();
        this.driver = driver;
        screenShotCapturer = new ScreenShotCapturer(this.driver);
        status = "";
    }

    public void switchFrame(WebElement element){
        driver.switchTo().frame(element);
    }

    public void resetFrame(){
        driver.switchTo().defaultContent();
    }

    public void captureText(String text, WebElement element) {
        PageLoadWaiterClass.waitAllRequest(driver);

        try {
            waitForElementVisibility(element);
            element.sendKeys(text);
            status = "passed";
            if (element.getAttribute("name").equalsIgnoreCase("abPassword")){
                text = "##########";
            }
        }catch (NoSuchElementException | TimeoutException e){
            status = "failed";

        }

        if (status.equalsIgnoreCase("passed")){
            screenShotCapturer.takeScreenshotOfFullPage("Capture " + text + " on " + element.getAttribute("name") + " text field", status);
        }else if (status.equalsIgnoreCase("failed")){
            screenShotCapturer.takeScreenshotOfFullPage("Failed to interact with object", status);
            throw new NoSuchElementException("Object no found");
        }

    }

    public void clickObject(WebElement element) {
        PageLoadWaiterClass.waitAllRequest(driver);
        String elementType = "";
        String elementName = "";
        try {
            waitForElementVisibility(element);
            if (element.getTagName().equalsIgnoreCase("a")){
                elementType = "linktext";
                elementName = element.getText();
            }else if(element.getAttribute("name").contains("button")){
                elementType = "button";
                elementName = element.getAttribute("value");
            }

            status = "passed";
        }catch (NoSuchElementException | TimeoutException e){
            status = "failed";
        }

        if (status.equalsIgnoreCase("passed")){
            element.click();
            try {
                screenShotCapturer.takeScreenshotOfFullPage("Click the " + elementName + " " + elementType, status);
            }catch (NoSuchWindowException e){
                e.printStackTrace();
            }

        }else {
            screenShotCapturer.takeScreenshotOfFullPage("Failed to interact with element", status);
            throw new NoSuchElementException("Object no found");
        }

    }

    public void getAndAssertText(WebElement element, String expectedText) {
        PageLoadWaiterClass.waitAllRequest(driver);
        waitForElementVisibility(element);
        String actualText = element.getText();
        System.out.println("Expected: " + expectedText + "\nActual: " + actualText);
        Assert.assertEquals(expectedText, actualText);
    }

    private void waitForElementVisibility(WebElement element){
        new WebDriverWait(driver, 15).until(ExpectedConditions.visibilityOfAllElements(element));
    }

    public void getAndAssertTrimmedText(WebElement element, String expectedText) {
        PageLoadWaiterClass.waitAllRequest(driver);
        waitForElementVisibility(element);
        String actualText = element.getText().trim();
        System.out.println("Expected: " + expectedText.trim() + "\nActual: " + actualText);
        Assert.assertEquals(expectedText.trim(), actualText);
    }

    public String getText(WebElement element){
        return element.getText();
    }

    public void selectOptionByText(WebElement element, String text) {
        PageLoadWaiterClass.waitAllRequest(driver);

        try {
            waitForElementVisibility(element);
            Select select = new Select(element);
            select.selectByVisibleText(text);
            status = "passed";
        } catch (NoSuchElementException e) {
            status = "failed";
        }
        if (status.equalsIgnoreCase("passed")) {
            screenShotCapturer.takeScreenshotOfFullPage("Select " + text + " option from " + element.getAttribute("name"), status);
        } else {
            screenShotCapturer.takeScreenshotOfFullPage("Failed to interact with element", status);
            throw new NoSuchElementException("Object no found");
        }
    }

    public void selectOptionByIndex(WebElement element, int index){
        PageLoadWaiterClass.waitAllRequest(driver);
        waitForElementVisibility(element);
        Select select = new Select(element);
        select.selectByIndex(index);
    }

    public String getWindowHandle(){
        return driver.getWindowHandle();
    }

    public Set<String> getWindowHandles(){
        return driver.getWindowHandles();
    }

    public void switchWindow(String window){
        driver.switchTo().window(window);
    }

    public void closeDriver(){
        driver.close();
    }


}
