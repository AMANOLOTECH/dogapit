package za.co.absa.webPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import za.co.absa.Base.BaseClass;
import za.co.absa.customexceptions.DataNotFoundException;
import za.co.absa.managers.FileReaderManager;

import java.io.IOException;

public class HomeLoansHomePage {
    WebDriver driver;
    BaseClass baseClass;

    public HomeLoansHomePage(WebDriver driver) {
        this.driver = driver;
        baseClass = new BaseClass(this.driver);
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(name = "main")
    private WebElement frmMain;

    @FindBy(name = "abUser")
    private WebElement txtUsername;

    @FindBy(name = "abPassword")
    private WebElement txtPassword;

    @FindBy(name = "button_authenticate")
    private WebElement btnAuthenticate;


    public void captureUsername(String credentialValidity) throws IOException, DataNotFoundException {
        String username = "";
        if (credentialValidity.equalsIgnoreCase("an incorrect")) {
            username = FileReaderManager.getInstance().getDataReader().getRequiredData("incorrectUsername");
        } else if (credentialValidity.equalsIgnoreCase("a correct")) {
            username = FileReaderManager.getInstance().getDataReader().getRequiredData("username");
        }

        baseClass.switchFrame(frmMain);
        baseClass.captureText(username, txtUsername);
    }

    public void capturePassword(String credentialValidity) throws IOException, DataNotFoundException {
        String password = "";
        if (credentialValidity.equalsIgnoreCase("an incorrect")) {
            password = FileReaderManager.getInstance().getDataReader().getRequiredData("incorrectPassword");
        } else if (credentialValidity.equalsIgnoreCase("a correct")) {
            password = FileReaderManager.getInstance().getDataReader().getRequiredData("password");
        }
        baseClass.captureText(password, txtPassword);
    }

    public void clickAuthenticate() {
        baseClass.clickObject(btnAuthenticate);
    }

    public String getAuthenticateText() {
        return baseClass.getText(btnAuthenticate);
    }


}


