package za.co.absa.customexceptions;

public class UrlNotFoundException extends Exception{
    public UrlNotFoundException(String s){
        super(s);
    }
}
