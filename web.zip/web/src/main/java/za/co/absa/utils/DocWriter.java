package za.co.absa.utils;

import java.io.FileWriter;
import java.io.IOException;

public class DocWriter {

    public DocWriter(){
        //Intentionally left blank
    }

    public void writeToWordDocument(String fileName, String text) {
        try {
            FileWriter fw = new FileWriter(fileName, true);
            fw.write(text);
            fw.close();
        } catch (
                IOException e) {
            e.printStackTrace();
        }
    }

}
