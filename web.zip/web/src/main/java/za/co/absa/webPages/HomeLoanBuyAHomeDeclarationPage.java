package za.co.absa.webPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import za.co.absa.Base.BaseClass;

public class HomeLoanBuyAHomeDeclarationPage {
    WebDriver driver;
    BaseClass baseClass;

    public HomeLoanBuyAHomeDeclarationPage(WebDriver driver){
        this.driver = driver;
        baseClass = new BaseClass(driver);
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(name="button_continue")
    private WebElement btnContinue;

    @FindBy(name = "main")
    private WebElement frameMain;

    public void clickContinue(){
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        baseClass.clickObject(btnContinue);
    }
}
