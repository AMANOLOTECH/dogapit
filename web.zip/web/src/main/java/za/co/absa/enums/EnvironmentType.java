package za.co.absa.enums;

public enum EnvironmentType {
    QA,
    ETE
}
