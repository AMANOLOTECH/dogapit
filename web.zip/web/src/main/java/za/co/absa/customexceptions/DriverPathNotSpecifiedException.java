package za.co.absa.customexceptions;

public class DriverPathNotSpecifiedException extends Exception{
    public DriverPathNotSpecifiedException(String s){
        super(s);
    }
}
