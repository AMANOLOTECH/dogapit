package za.co.absa.enums;

public enum DriverType {
    FIREFOX,
    CHROME,
    INTERNETEXPLORER,
    EDGE
}
