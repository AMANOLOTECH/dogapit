package za.co.absa.webPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import za.co.absa.Base.BaseClass;

public class HomeLoansLandingPage {
    WebDriver driver;
    BaseClass baseClass;

    public HomeLoansLandingPage(WebDriver driver) {
        this.driver = driver;
        baseClass = new BaseClass(driver);
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(xpath = "//a[@class = \"boldLink\" and contains(. , \"Calculator\")]")
    private WebElement lnkCalculator;

    @FindBy(xpath = "//a[. = \"Apply for a home loan\"]")
    private WebElement lnkApplyForHomeLoan;

    @FindBy(xpath = "//a[contains(.,\"Buy a home\")]")
    private WebElement lnkBuyAHome;

    @FindBy(xpath = "//a[contains(.,\"Build a home\")]")
    private WebElement lnkBuildAHome;

    @FindBy(xpath = "//a[contains(.,\"Increase your existing loan\")]")
    private WebElement lnkIncreaseYourExistingLoan;

    @FindBy(xpath = "//frame[@name=\"contents\"]")
    private WebElement frameSideNavigation;

    @FindBy(xpath = "//a[. = \"Admin functions\"]")
    private WebElement lnkAdminFunctions;

    @FindBy(xpath = "//a[contains(., \"Validation listing\")]")
    private WebElement lnkValidationListing;

    @FindBy(xpath = "//a[contains(., \"Verify client\")]")
    private WebElement lnkVerifyClient;

    @FindBy(name = "main")
    private WebElement frameMain;


    public void assertLandingPage() {
        baseClass.getAndAssertText(lnkCalculator, "Calculator");
    }

    public void clickApplyForHomeLoan() {
        baseClass.clickObject(lnkApplyForHomeLoan);
    }

    public void clickAdminFunctions(){
        System.out.println(baseClass.getText(lnkAdminFunctions));
        baseClass.clickObject(lnkAdminFunctions);
    }

    public void clickValidationListing(){
        baseClass.clickObject(lnkValidationListing);
    }

    public void clickVerifyClient(){
        baseClass.clickObject(lnkVerifyClient);
    }

    public void clickBuyAHome() {
        baseClass.clickObject(lnkBuyAHome);
    }

    public void clickBuildAHome() {
        baseClass.clickObject(lnkBuildAHome);
    }

    public void clickIncreaseYourExistingLoan() {
        baseClass.clickObject(lnkIncreaseYourExistingLoan);
    }

    public void switchFrameToSideNavigation() {
        baseClass.resetFrame();
        baseClass.switchFrame(frameSideNavigation);
    }

    public void switchFrameToMain() {
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
    }
}


