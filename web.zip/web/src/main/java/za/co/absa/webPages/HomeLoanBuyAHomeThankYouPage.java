package za.co.absa.webPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import za.co.absa.Base.BaseClass;

public class HomeLoanBuyAHomeThankYouPage {
    WebDriver driver;
    BaseClass baseClass;

    public HomeLoanBuyAHomeThankYouPage(WebDriver driver){
        this.driver = driver;
        baseClass = new BaseClass(this.driver);
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(name = "backToMain")
    private WebElement btnBackToMain;

    @FindBy(name = "main")
    private WebElement frameMain;

    public void clickBackToMain(){
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        baseClass.clickObject(btnBackToMain);
    }
}
