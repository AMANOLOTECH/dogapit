package za.co.absa.customexceptions;

public class DataNotFoundException extends Exception{
    public DataNotFoundException(String s){
        super(s);
    }
}
