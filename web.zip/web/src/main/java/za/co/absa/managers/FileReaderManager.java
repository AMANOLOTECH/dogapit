package za.co.absa.managers;

import za.co.absa.dataReader.ApplicationNumberReader;
import za.co.absa.dataReader.ConfigReader;
import za.co.absa.dataReader.DataReader;

import java.io.IOException;

public class FileReaderManager {

    private static final FileReaderManager fileReaderManager = new FileReaderManager();
    private static DataReader dataReader;
    private static ConfigReader configReader;
    private static ApplicationNumberReader applicationNumberReader;

    private FileReaderManager(){

    }

    public static FileReaderManager getInstance(){
        return fileReaderManager;
    }

    public ConfigReader getConfigReader() throws IOException {
        return (configReader == null) ? new ConfigReader() : configReader;
    }

    public DataReader getDataReader() throws IOException{
        return (dataReader == null) ? new DataReader() : dataReader;
    }

    public ApplicationNumberReader getApplicationNumberReader() throws IOException {
        return (applicationNumberReader == null) ? new ApplicationNumberReader() : applicationNumberReader;
     }
}
