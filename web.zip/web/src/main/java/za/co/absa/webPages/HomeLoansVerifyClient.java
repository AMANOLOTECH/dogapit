package za.co.absa.webPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import za.co.absa.Base.BaseClass;

public class HomeLoansVerifyClient {
    WebDriver driver;
    BaseClass baseClass;

    public HomeLoansVerifyClient(WebDriver driver){
        this.driver = driver;
        baseClass = new BaseClass(this.driver);
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(xpath = "//input[@name=\"applicationNo\"]")
    private WebElement txtApplicationNumber;

    @FindBy(name = "button_processApplicationNumber")
    private WebElement btnContinue;

    @FindBy(name = "button_continue")
    private WebElement btnContinueVerification;

    public void clickContinue(){
        baseClass.clickObject(btnContinue);
    }

    public void clickContinueVerification(){
        baseClass.clickObject(btnContinueVerification);
    }

    @FindBy(name = "main")
    private WebElement frameMain;

    public void captureApplicationNumber(String applicationNumber){
        baseClass.resetFrame();
        baseClass.switchFrame(frameMain);
        baseClass.captureText(applicationNumber, txtApplicationNumber);
    }


}
