package za.co.absa.utils;


import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;



public class ScreenShotCapturer {
    private WebDriver driver;

    public ScreenShotCapturer(WebDriver driver) {
        this.driver = driver;

    }

    public void takeScreenshotOfElement(WebElement element) {

        Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver, element);
        BufferedImage actualImage = screenshot.getImage();
        try {
            ImageIO.write(actualImage, "PNG", new File("src/test/resources/screenshots/" + element.getAttribute("name") + ".png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void takeScreenshotOfFullPage(String text, String status) {
        LocalDateTime localDateTime = LocalDateTime.now();
        int day = localDateTime.getDayOfMonth();
        String month = localDateTime.getMonth().toString();
        int year = localDateTime.getYear();
        String time;
        try{
            time = localDateTime.toLocalTime().toString().replaceAll(":", "").substring(0, 9);
        }catch (StringIndexOutOfBoundsException e){
            time = localDateTime.toLocalTime().toString().replaceAll(":", "").substring(0, 8);
        }


        File filePath = new File("src/test/resources/screenshots/"
                + "/" + year
                + "/" + month
                + "/" + day
                + "/" + status);

        String fileName = time + "_" + text + ".png";

        TakesScreenshot scrShot = ((TakesScreenshot) driver);

        File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);

        File DestFile = new File(filePath, fileName);

        try {
            FileUtils.copyFile(SrcFile, DestFile);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
