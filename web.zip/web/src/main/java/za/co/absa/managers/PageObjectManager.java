package za.co.absa.managers;

import org.openqa.selenium.WebDriver;
import za.co.absa.webPages.*;

public class PageObjectManager {
    private WebDriver driver;
    HomeLoansHomePage homeLoansHomePage;
    HomeLoansLandingPage homeLoansLandingPage;
    HomeLoansBuyAHomePage homeLoansBuyAHomePage;
    HomeLoansBuyAHomeAboutYourFinancesPage homeLoansBuyAHomeAboutYourFinancesPage;
    HomeLoansBuyAHomeLoanDetailsPage homeLoansBuyAHomeLoanDetailsPage;
    HomeLoanBuyAHomePropertyDetailsPage homeLoanBuyAHomePropertyDetailsPage;
    HomeLoanBuyAHomeDeclarationPage homeLoanBuyAHomeDeclarationPage;
    HomeLoanBuyAHomeThankYouPage homeLoanBuyAHomeThankYouPage;
    HomeLoansVerifyClient homeLoansVerifyClient;
    HomeLoansValidationListing homeLoansValidationListing;

    public PageObjectManager(WebDriver driver){
        this.driver = driver;
    }

    public HomeLoansHomePage getHomeLoansHomePage() {
        return (homeLoansHomePage == null) ? homeLoansHomePage = new HomeLoansHomePage(driver) : homeLoansHomePage;
    }

    public HomeLoansLandingPage getHomeLoansLandingPage(){
        return (homeLoansLandingPage == null) ? homeLoansLandingPage = new HomeLoansLandingPage(driver) : homeLoansLandingPage;
    }

    public HomeLoansBuyAHomePage getHomeLoansBuyAHomePage(){
        return (homeLoansBuyAHomePage == null) ? homeLoansBuyAHomePage = new HomeLoansBuyAHomePage(driver) : homeLoansBuyAHomePage;
    }

    public HomeLoansBuyAHomeAboutYourFinancesPage getHomeLoansBuyAHomeAboutYourFinances(){
        return (homeLoansBuyAHomeAboutYourFinancesPage == null) ? homeLoansBuyAHomeAboutYourFinancesPage = new HomeLoansBuyAHomeAboutYourFinancesPage(driver) : homeLoansBuyAHomeAboutYourFinancesPage;
    }

    public HomeLoansBuyAHomeLoanDetailsPage getHomeLoansBuyAHomeLoanDetails(){
        return (homeLoansBuyAHomeLoanDetailsPage == null) ? homeLoansBuyAHomeLoanDetailsPage = new HomeLoansBuyAHomeLoanDetailsPage(driver) : homeLoansBuyAHomeLoanDetailsPage;
    }

    public HomeLoanBuyAHomePropertyDetailsPage getHomeLoanBuyAHomePropertyDetails(){
        return (homeLoanBuyAHomePropertyDetailsPage == null) ? homeLoanBuyAHomePropertyDetailsPage = new HomeLoanBuyAHomePropertyDetailsPage(driver) : homeLoanBuyAHomePropertyDetailsPage;
    }

    public HomeLoanBuyAHomeDeclarationPage getHomeLoanBuyAHomeDeclarationPage(){
        return (homeLoanBuyAHomeDeclarationPage == null) ? homeLoanBuyAHomeDeclarationPage = new HomeLoanBuyAHomeDeclarationPage(driver) : homeLoanBuyAHomeDeclarationPage;
    }

    public HomeLoanBuyAHomeThankYouPage getHomeLoanBuyAHomeThankYouPage(){
        return (homeLoanBuyAHomeThankYouPage == null) ? homeLoanBuyAHomeThankYouPage = new HomeLoanBuyAHomeThankYouPage(driver) : homeLoanBuyAHomeThankYouPage;
    }

    public HomeLoansVerifyClient getHomeLoansVerifyClient(){
        return (homeLoansVerifyClient == null) ? homeLoansVerifyClient = new HomeLoansVerifyClient(driver) : homeLoansVerifyClient;
    }

    public HomeLoansValidationListing getHomeLoansValidationListing(){
        return (homeLoansValidationListing == null) ? homeLoansValidationListing = new HomeLoansValidationListing(driver) : homeLoansValidationListing;
    }
}
