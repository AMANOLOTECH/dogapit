package za.co.absa.dataReader;

import za.co.absa.customexceptions.DataNotFoundException;

import java.io.*;
import java.util.Properties;

public class ApplicationNumberReader {
    Properties properties;
    private static final String APPLICATION_NUMBER_PROPERTY_PATH = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testData" + File.separator + "applicationNumber.properties";
    public ApplicationNumberReader() throws IOException{
        try (BufferedReader reader = new BufferedReader(new FileReader(APPLICATION_NUMBER_PROPERTY_PATH))){
            properties = new Properties();
            readProperties(properties, reader);
        }catch (FileNotFoundException e){
            throw new FileNotFoundException("Required file not found: " + APPLICATION_NUMBER_PROPERTY_PATH);
        }
    }

    private void readProperties(Properties properties, BufferedReader reader){
        try {
            properties.load(reader);
            reader.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public String getApplicationNumber() throws DataNotFoundException{
        String data = properties.getProperty("applicationNumber");
        if (data != null) return data;
        throw new DataNotFoundException("Required data not found in " + APPLICATION_NUMBER_PROPERTY_PATH);
    }
}
