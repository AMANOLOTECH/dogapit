

package za.co.absa.runners;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;



@RunWith(Cucumber.class)
@CucumberOptions(
        glue = {"za.co.absa.stepDefinitions"},
        features = {"src/test/resources/features"},
        tags = ("@Login"),
       // plugin = {"com.vimalselvam.cucumber.listener.ExtentCucumberFormatter:target/html/ExtentReport.html"},
        monochrome = true
)
public class TestRunner {


/*    @After
    public static void teardown() throws IOException {
        Reporter.loadXMLConfig((new File("src/test/resources/extent-config.xml")));
        Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
        Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
        Reporter.setSystemInfo("Machine", "Windows 10" + "64 Bit");
        Reporter.setSystemInfo("Selenium", "3.7.0");
        Reporter.setSystemInfo("Maven", "3.5.2");
        Reporter.setSystemInfo("Java Version", "1.8.0_151");
    }*/
}
