package za.co.absa.stepDefinitions;

import com.github.javafaker.Faker;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.After;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.FluentWait;
import za.co.absa.customexceptions.ConfigurationKeyNotMatchedException;
import za.co.absa.customexceptions.DataNotFoundException;
import za.co.absa.managers.FileReaderManager;
import za.co.absa.managers.PageObjectManager;
import za.co.absa.managers.WebDriverManager;
import za.co.absa.utils.DocWriter;
import za.co.absa.webPages.*;

import java.io.*;
import java.time.Duration;


public class HomeLoans {
    WebDriver driver;
    WebDriverManager webDriverManager;
    PageObjectManager pageObjectManager;
    HomeLoansHomePage homeLoansHomePage;
    HomeLoansLandingPage homeLoansLandingPage;
    HomeLoansBuyAHomePage homeLoansBuyAHomePage;
    HomeLoansBuyAHomeAboutYourFinancesPage homeLoansBuyAHomeAboutYourFinancesPage;
    HomeLoansBuyAHomeLoanDetailsPage homeLoansBuyAHomeLoanDetailsPage;
    HomeLoanBuyAHomePropertyDetailsPage homeLoanBuyAHomePropertyDetailsPage;
    HomeLoanBuyAHomeDeclarationPage homeLoanBuyAHomeDeclarationPage;
    HomeLoanBuyAHomeThankYouPage homeLoanBuyAHomeThankYouPage;
    HomeLoansVerifyClient homeLoansVerifyClient;
    HomeLoansValidationListing homeLoansValidationListing;
    DocWriter docWriter;

    //Variables for test context
    String id = "";
    String typeOfLoan = "";


    public HomeLoans() throws IOException, ConfigurationKeyNotMatchedException {
        webDriverManager = new WebDriverManager();
        driver = webDriverManager.createDriver();
        pageObjectManager = new PageObjectManager(driver);
        homeLoansHomePage = pageObjectManager.getHomeLoansHomePage();
        homeLoansBuyAHomePage = pageObjectManager.getHomeLoansBuyAHomePage();
        homeLoansLandingPage = pageObjectManager.getHomeLoansLandingPage();
        homeLoansBuyAHomeAboutYourFinancesPage = pageObjectManager.getHomeLoansBuyAHomeAboutYourFinances();
        homeLoansBuyAHomeLoanDetailsPage = pageObjectManager.getHomeLoansBuyAHomeLoanDetails();
        homeLoanBuyAHomePropertyDetailsPage = pageObjectManager.getHomeLoanBuyAHomePropertyDetails();
        homeLoanBuyAHomeDeclarationPage = pageObjectManager.getHomeLoanBuyAHomeDeclarationPage();
        homeLoanBuyAHomeThankYouPage = pageObjectManager.getHomeLoanBuyAHomeThankYouPage();
        homeLoansVerifyClient = pageObjectManager.getHomeLoansVerifyClient();
        homeLoansValidationListing = pageObjectManager.getHomeLoansValidationListing();
        docWriter = new DocWriter();

    }

    @Given("^I am on the homeloans home page$")
    public void iAmOnHomeLoansHomePage() {
        //Runtime.getRuntime().exec("cmd /c start C:\\Users\\AB0150C\\IdeaProjects\\framework\\web\\src\\main\\resources\\configs\\passport.bat");
        driver.get("https://wassit.absa.co.za/homeloans/eoml.jsp?orig=intra");

    }


    @And("^I click Authenticate$")
    public void iClickAuthenticate() {
        homeLoansHomePage.clickAuthenticate();
    }

    @Then("^I must \"([^\"]*)\" logged in$")
    public void iMustLoggedIn(String loginStatus) {

        if (loginStatus.equalsIgnoreCase("be")) {
            homeLoansLandingPage.assertLandingPage();
        } else if (loginStatus.equalsIgnoreCase("not be")) {
            try {
                Assert.assertEquals("Authenticate", homeLoansHomePage.getAuthenticateText());
            } catch (NoSuchElementException e) {
                Assert.fail("NoSuchElementException: The \"Authenticate\" button not found");
            }
        }
    }


    @Given("^I want to apply for a \"([^\"]*)\" loan$")
    public void iApplyForAHomeLoanToAHome(String loanType) throws IOException {
        homeLoansLandingPage.switchFrameToSideNavigation();
        homeLoansLandingPage.clickApplyForHomeLoan();
        this.typeOfLoan = loanType;
        if (loanType.equalsIgnoreCase("home")) {
            homeLoansLandingPage.clickBuyAHome();
        } else if (loanType.equalsIgnoreCase("building")) {
            homeLoansLandingPage.clickBuildAHome();
        } else if (loanType.equalsIgnoreCase("further advance")) {
            homeLoansLandingPage.clickIncreaseYourExistingLoan();
        }


    }

    @When("^I capture \"([^\"]*)\" username and password$")
    public void iCaptureUsernameAndPassword(String credentialValidity) throws IOException, DataNotFoundException {
        homeLoansHomePage.captureUsername(credentialValidity);
        homeLoansHomePage.capturePassword(credentialValidity);
    }

    @Then("I must get an error message")
    public void iMustGetAnErrorMessage() {

    }
/*
    @After
    public void tearDown(){
        driver.close();
    }*/

    public void buildingLoan() throws IOException, DataNotFoundException {
        homeLoansBuyAHomePage.selectTypeOfApplication("Individual");
        homeLoansBuyAHomePage.clickReApplicationYesOrNo(false);
        homeLoansBuyAHomePage.clickCommercialPropertyYesOrNo(false);
        homeLoansBuyAHomePage.selectResidentialPropertyType("House");
        homeLoansBuyAHomePage.selectOccupiedBy("Owner");
        homeLoansBuyAHomePage.clickABSAPropertyInsuranceYesOrNo(false);
        homeLoansBuyAHomePage.clickLifeInsuranceQuoteYesOrNo(false);
        homeLoansBuyAHomePage.clickConsultantCallForWillYesOrNo(false);
        homeLoansBuyAHomePage.clickSuretyAvailableYesOrNo(false);
        homeLoansBuyAHomePage.captureGrossMonthlyIncome(FileReaderManager.getInstance().getDataReader().getRequiredData("monthlyIncome"));
        homeLoansBuyAHomePage.capturePurchasePrice("500000");
        homeLoansBuyAHomePage.captureLoanAmountRequired("500000");
        homeLoansBuyAHomePage.clickAreYouApplicantYesOrNo(true);
        homeLoansBuyAHomePage.clickCreditCheckConsentYesOrNo(true);
        homeLoansBuyAHomePage.capturePreferedBranch("Randburg");
        homeLoansBuyAHomePage.clickSearchPreferedBranch();
        homeLoansBuyAHomePage.clickPreferedBranchResult();
        homeLoansBuyAHomePage.clickGettingStartedContinue();
    }

    public void buyAHouse() throws IOException, DataNotFoundException {
        homeLoansBuyAHomePage.selectTypeOfApplication("Individual");
        homeLoansBuyAHomePage.clickReceivedEstimatorFromABSAYesOrNo(false);
        homeLoansBuyAHomePage.clickReApplicationYesOrNo(false);
        homeLoansBuyAHomePage.clickCommercialPropertyYesOrNo(false);
        homeLoansBuyAHomePage.selectResidentialPropertyType("House");
        homeLoansBuyAHomePage.selectOccupiedBy("Owner");
        homeLoansBuyAHomePage.clickABSAPropertyInsuranceYesOrNo(false);
        homeLoansBuyAHomePage.clickLifeInsuranceQuoteYesOrNo(false);
        homeLoansBuyAHomePage.clickConsultantCallForWillYesOrNo(false);
        homeLoansBuyAHomePage.clickSuretyAvailableYesOrNo(false);
        homeLoansBuyAHomePage.clickDebtConsolidationYesOrNo(false);
        homeLoansBuyAHomePage.captureGrossMonthlyIncome(FileReaderManager.getInstance().getDataReader().getRequiredData("monthlyIncome"));
        homeLoansBuyAHomePage.capturePurchasePrice("500000");
        homeLoansBuyAHomePage.captureLoanAmountRequired("500000");
        homeLoansBuyAHomePage.clickAreYouApplicantYesOrNo(true);
        homeLoansBuyAHomePage.clickCreditCheckConsentYesOrNo(true);
        homeLoansBuyAHomePage.capturePreferedBranch("Randburg");
        homeLoansBuyAHomePage.clickSearchPreferedBranch();
        homeLoansBuyAHomePage.clickPreferedBranchResult();
        homeLoansBuyAHomePage.clickGettingStartedContinue();
    }

    public void furtherAdvance(String loanAccNumber) {
        homeLoansBuyAHomePage.clickReApplicationYesOrNo(false);
        homeLoansBuyAHomePage.selectOccupiedBy("Owner");
        homeLoansBuyAHomePage.clickLifeInsuranceQuoteYesOrNo(false);
        homeLoansBuyAHomePage.clickConsultantCallForWillYesOrNo(false);
        homeLoansBuyAHomePage.captureExistingAccountNumber(loanAccNumber);
        homeLoansBuyAHomePage.clickDebtConsolidationYesOrNo(false);
        homeLoansBuyAHomePage.captureLoanAmountRequired("150000");
        homeLoansBuyAHomePage.clickAreYouApplicantYesOrNo(true);
        homeLoansBuyAHomePage.clickCreditCheckConsentYesOrNo(true);
        homeLoansBuyAHomePage.capturePreferedBranch("Randburg");
        homeLoansBuyAHomePage.clickSearchPreferedBranch();
        homeLoansBuyAHomePage.clickPreferedBranchResult();
        homeLoansBuyAHomePage.clickGettingStartedContinue();


    }


    public void gettingStartedDetails(String loanAccNumber) throws IOException, DataNotFoundException {

        System.out.println(typeOfLoan);
        if (typeOfLoan.equalsIgnoreCase("home")) {
            buyAHouse();
        } else if (typeOfLoan.equalsIgnoreCase("further advance")) {
            furtherAdvance(loanAccNumber);
        } else if (typeOfLoan.equalsIgnoreCase("building")) {
            buildingLoan();
        }


    }

    public void aboutYouAndYourFinances(String idNumber) throws IOException, DataNotFoundException {
        Faker faker = new Faker();
        String fullName, surname;
        fullName = faker.name().firstName();
        surname = faker.name().lastName();
        homeLoansBuyAHomeAboutYourFinancesPage.selectPreferredCommunicationChannel(homeLoansReader("preferredCommunicationChannel"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureCellNumber(homeLoansReader("cellNumber"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureEmailAddress(homeLoansReader("email"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureSurname(surname);
        homeLoansBuyAHomeAboutYourFinancesPage.captureFullNames(fullName);
        homeLoansBuyAHomeAboutYourFinancesPage.selectIDType(homeLoansReader("idType"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureIDNUmber(idNumber);
        homeLoansBuyAHomeAboutYourFinancesPage.selectEmploymentStatus(homeLoansReader("employmentStatus"));
        homeLoansBuyAHomeAboutYourFinancesPage.clickIncomeBracketTwo();
        homeLoansBuyAHomeAboutYourFinancesPage.selectMaritalStatus(homeLoansReader("maritalStatus"));

        try {
            homeLoansBuyAHomeAboutYourFinancesPage.clickContinue();
            System.out.println("Alert: " + driver.switchTo().alert().getText() + " displayed");
            driver.switchTo().alert().accept();

        } catch (UnhandledAlertException | TimeoutException e) {

            homeLoansBuyAHomeAboutYourFinancesPage.clickParticipantToComplete();


        }
        //homeLoansBuyAHomeAboutYourFinancesPage.clickParticipantToComplete();
        homeLoansBuyAHomeAboutYourFinancesPage.clickComplete();
        if (typeOfLoan.equalsIgnoreCase("further advance")) {
            existingClient();
        } else if (typeOfLoan.equalsIgnoreCase("home")) {
            newClient(idNumber);
        }


        homeLoansBuyAHomeAboutYourFinancesPage.captureTotalMonthlyIncome(homeLoansReader("monthlyIncome"), homeLoansReader("commission"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureTotalDeductions(homeLoansReader("tax"),
                homeLoansReader("uif"),
                homeLoansReader("pension"),
                homeLoansReader("medicalAid"));
/*        homeLoansBuyAHomeAboutYourFinancesPage.captureTotalMonthlyFixedDebtRepayments(homeLoansReader("totalMonthlyHomeLoanRepayment"),
                homeLoansReader("loanToBeStopped"),
                homeLoansReader("assetFinanceVehicleRepayment"),
                homeLoansReader("loanOverdraftRepayments"),
                homeLoansReader("creditCardsRepayments"),
                homeLoansReader("otherAccountRepayments"),
                homeLoansReader("otherFixedDebtRepayments"));*/
        homeLoansBuyAHomeAboutYourFinancesPage.captureTotalMonthlyLivingExpenses(homeLoansReader("totalMonthlyLivingExpenses"));
        homeLoansBuyAHomeAboutYourFinancesPage.clickCreditCardYesOrNo(false);
        homeLoansBuyAHomeAboutYourFinancesPage.selectSalaryDepositedAccountType(homeLoansReader("accountType"));
        homeLoansBuyAHomeAboutYourFinancesPage.selectBankInstitutionName(homeLoansReader("bankName"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureAccountNumber(homeLoansReader("absaBankAccNum"));
        // homeLoansBuyAHomeAboutYourFinancesPage.clickChequeYesOrNo(true);
        homeLoansBuyAHomeAboutYourFinancesPage.clickOtherIncomePaidInAnotherAccountYesOrNo(false);
        homeLoansBuyAHomeAboutYourFinancesPage.clickConsentToRequestStatements(true);
        if (!typeOfLoan.equalsIgnoreCase("further advance")) {
            homeLoansBuyAHomeAboutYourFinancesPage.clickExistingHLToBeCancelledYesOrNo(false);
        }

        homeLoansBuyAHomeAboutYourFinancesPage.clickUnderDebtCounsellingYesOrNo(false);
        homeLoansBuyAHomeAboutYourFinancesPage.clickDeclaredInsolventYesOrNo(false);
        homeLoansBuyAHomeAboutYourFinancesPage.clickContinue();
        homeLoansBuyAHomeAboutYourFinancesPage.clickParticipantToComplete();
        homeLoansBuyAHomeAboutYourFinancesPage.clickContinue();

    }

    public void loanDetails(boolean multiPlan) throws IOException, DataNotFoundException {
        String bondRegistrationAmount = "";
        if (typeOfLoan.equalsIgnoreCase("further advance")) {
            bondRegistrationAmount = homeLoansReader("bondRegistrationAmountFAO");
        } else {
            bondRegistrationAmount = homeLoansReader("bondRegistrationAmount");
        }
        homeLoansBuyAHomeLoanDetailsPage.captureBondRegistrationAmount(bondRegistrationAmount);
        if (!typeOfLoan.equalsIgnoreCase("further advance")) {
            homeLoansBuyAHomeLoanDetailsPage.captureDateOfPurchase(homeLoansReader("dateOfPurchase"));
            homeLoansBuyAHomeLoanDetailsPage.selectRepaymentDay(homeLoansReader("dateOfRepayment"));
        }
        homeLoansBuyAHomeLoanDetailsPage.selectTermOfLoan("20");
        homeLoansBuyAHomeLoanDetailsPage.clickMultiPlanYesOrNo(multiPlan);
        if (multiPlan) {
            homeLoansBuyAHomeLoanDetailsPage.captureMultiplanName("test");
            homeLoansBuyAHomeLoanDetailsPage.selectTermOfMultiplanLoan("18");
            homeLoansBuyAHomeLoanDetailsPage.captureMultiplanLoanAmount("123456");
        }


        if (typeOfLoan.equalsIgnoreCase("further advance")) {
            homeLoansBuyAHomeLoanDetailsPage.captureValuationName("Thabiso Makgotloe");
            homeLoansBuyAHomeLoanDetailsPage.captureValuationContactNumber("0781234567");
        }

        homeLoansBuyAHomeLoanDetailsPage.clickContinue();
    }

    public void propertyDetails(String idNumber, String streetNumber, String streetName, String suburbName) throws IOException, DataNotFoundException {
        Faker faker = new Faker();
        String erfNumber = Integer.toString(faker.number().numberBetween(1, 5000));
        homeLoanBuyAHomePropertyDetailsPage.selectCurrentOwnerIdentityType(homeLoansReader("currentOwnerIdentityType"));
        homeLoanBuyAHomePropertyDetailsPage.captureSellerID(idNumber);
        //homeLoanBuyAHomePropertyDetailsPage.captureStreetName(streetName);
        //homeLoanBuyAHomePropertyDetailsPage.captureStreetNumber(streetNumber);
        homeLoanBuyAHomePropertyDetailsPage.captureErfNumber(erfNumber);
        homeLoanBuyAHomePropertyDetailsPage.captureSuburbName(suburbName);
        homeLoanBuyAHomePropertyDetailsPage.clickSuburbSearchButton();
        homeLoanBuyAHomePropertyDetailsPage.clickResultFromSearch();
        homeLoanBuyAHomePropertyDetailsPage.selectWallType(homeLoansReader("wallType"));
        homeLoanBuyAHomePropertyDetailsPage.selectRoofType(homeLoansReader("roofType"));
        homeLoanBuyAHomePropertyDetailsPage.clickThatchRoofYesOrNo(false);
        homeLoanBuyAHomePropertyDetailsPage.clickPrimaryResidenceYesOrNo(true);
        homeLoanBuyAHomePropertyDetailsPage.captureValuationContactName(homeLoansReader("valuationContactName"));
        homeLoanBuyAHomePropertyDetailsPage.captureBondAttorneyName(homeLoansReader("bondAttorneyName"));
        homeLoanBuyAHomePropertyDetailsPage.clickAttorneyNameSearchButton();
        homeLoanBuyAHomePropertyDetailsPage.clickResultFromSearch();


        try {
            new FluentWait<>(driver)
                    .ignoring(NoAlertPresentException.class)
                    .withTimeout(Duration.ofSeconds(10))
                    .pollingEvery(Duration.ofSeconds(1))
                    .until((Object args) -> {
                        homeLoanBuyAHomePropertyDetailsPage.clickSearchPropertyButton();
                        System.out.println("Alert: " + driver.switchTo().alert().getText() + " displayed");
                        driver.switchTo().alert().accept();

                        return true;
                    });

        } catch (UnhandledAlertException | TimeoutException e) {

            homeLoanBuyAHomePropertyDetailsPage.clickNotFound();


        }


    }

    public void existingClientTwo() throws IOException, DataNotFoundException {
        String salutaion = null;
        System.out.println(Integer.parseInt(homeLoansReader("IDNumber").substring(6, 10)));
        if (Integer.parseInt(homeLoansReader("IDNumber").substring(6, 10)) >= 5000) {
            salutaion = "Mr";
        } else {
            salutaion = "Mrs";
        }
        System.out.println(salutaion);
        homeLoansBuyAHomeAboutYourFinancesPage.selectTitle(salutaion);
        homeLoansBuyAHomeAboutYourFinancesPage.selectCountryOfBirth(homeLoansReader("countryOfBirth"));
        homeLoansBuyAHomeAboutYourFinancesPage.selectNationality(homeLoansReader("nationality"));
        homeLoansBuyAHomeAboutYourFinancesPage.selectRace(homeLoansReader("race"));
        homeLoansBuyAHomeAboutYourFinancesPage.clickPostMatricQualificationYesOrNo(false);
        homeLoansBuyAHomeAboutYourFinancesPage.selectHomeLanguage(homeLoansReader("homeLanguage"));
        homeLoansBuyAHomeAboutYourFinancesPage.selectCorrespondenceLanguage(homeLoansReader("correspondenceLanguage"));
        homeLoansBuyAHomeAboutYourFinancesPage.selectCountryOfBirth(homeLoansReader("countryOfBirth"));
        homeLoansBuyAHomeAboutYourFinancesPage.clickContinue();
        homeLoansBuyAHomeAboutYourFinancesPage.selectPhysicalAddressCountry(homeLoansReader("physicalAddressCountry"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureAddress(homeLoansReader("addressLineOne")
                , homeLoansReader("addressLineTwo"),
                homeLoansReader("suburb"),
                homeLoansReader("city"),
                homeLoansReader("postalCode"));
        homeLoansBuyAHomeAboutYourFinancesPage.clickResidentialSameAsPostYesOrNo(true);
        homeLoansBuyAHomeAboutYourFinancesPage.captureCurrentAddressSince(homeLoansReader("currentAddressSince"));
        homeLoansBuyAHomeAboutYourFinancesPage.selectResidentialStatus(homeLoansReader("residentialStatus"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureCellNumber(homeLoansReader("cellNumber"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureEmailAddress(homeLoansReader("email"));
        homeLoansBuyAHomeAboutYourFinancesPage.clickContinue();
    }

    public void newClient(String idNumber) throws IOException, DataNotFoundException {
        Faker faker = new Faker();
        String addresslineOne, addresslineTwo;
        addresslineOne = faker.address().buildingNumber() + " " + faker.address().streetName();
        addresslineTwo = faker.address().cityName();
        String salutaion = null;
        System.out.println(Integer.parseInt(idNumber.substring(6, 10)));
        if (Integer.parseInt(idNumber.substring(6, 10)) >= 5000) {
            salutaion = "Mr";
        } else {
            salutaion = "Mrs";
        }
        System.out.println(salutaion);

        homeLoansBuyAHomeAboutYourFinancesPage.selectTitle(salutaion);
        homeLoansBuyAHomeAboutYourFinancesPage.selectCountryOfBirth(homeLoansReader("countryOfBirth"));
        homeLoansBuyAHomeAboutYourFinancesPage.selectNationality(homeLoansReader("nationality"));
        homeLoansBuyAHomeAboutYourFinancesPage.selectRace(homeLoansReader("race"));


        homeLoansBuyAHomeAboutYourFinancesPage.clickPostMatricQualificationYesOrNo(false);
        homeLoansBuyAHomeAboutYourFinancesPage.selectHomeLanguage(homeLoansReader("homeLanguage"));
        homeLoansBuyAHomeAboutYourFinancesPage.selectCorrespondenceLanguage(homeLoansReader("correspondenceLanguage"));
        homeLoansBuyAHomeAboutYourFinancesPage.selectCountryOfBirth(homeLoansReader("countryOfBirth"));
        homeLoansBuyAHomeAboutYourFinancesPage.clickContinue();
        homeLoansBuyAHomeAboutYourFinancesPage.selectPhysicalAddressCountry(homeLoansReader("physicalAddressCountry"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureAddress(addresslineOne
                , addresslineTwo,
                homeLoansReader("suburb"),
                homeLoansReader("city"),
                homeLoansReader("postalCode"));
        homeLoansBuyAHomeAboutYourFinancesPage.clickResidentialSameAsPostYesOrNo(true);
        homeLoansBuyAHomeAboutYourFinancesPage.captureCurrentAddressSince(homeLoansReader("currentAddressSince"));

        homeLoansBuyAHomeAboutYourFinancesPage.selectResidentialStatus(homeLoansReader("residentialStatus"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureCellNumber(homeLoansReader("cellNumber"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureEmailAddress(homeLoansReader("email"));
        homeLoansBuyAHomeAboutYourFinancesPage.clickContinue();
        homeLoansBuyAHomeAboutYourFinancesPage.selectEmploymentIndustry(homeLoansReader("employmentIndustry"));
        homeLoansBuyAHomeAboutYourFinancesPage.clickABSAStaffYesOrNo(false);
        homeLoansBuyAHomeAboutYourFinancesPage.captureEmployerName(homeLoansReader("employerName"));
        homeLoansBuyAHomeAboutYourFinancesPage.selectPresentOccupation(homeLoansReader("presentOccupation"));
        homeLoansBuyAHomeAboutYourFinancesPage.clickSocialGrantYesOrNo(false);
        homeLoansBuyAHomeAboutYourFinancesPage.captureEmployerAddress(homeLoansReader("employerAddressLineOne"),
                homeLoansReader("employerAddressLineTwo"),
                homeLoansReader("employerCity"),
                homeLoansReader("employerPostalAddress"));
        homeLoansBuyAHomeAboutYourFinancesPage.selectEmployerAddressCountry(homeLoansReader("employerAddressCountry"));
        homeLoansBuyAHomeAboutYourFinancesPage.captureCurrentEmploymentSinceDate(homeLoansReader("currentEmploymentSinceDate"));

        homeLoansBuyAHomeAboutYourFinancesPage.clickHousingSchemeYesOrNo(false);
        homeLoansBuyAHomeAboutYourFinancesPage.clickContinue();
    }

    public void existingClient() throws IOException, DataNotFoundException {
        {
            homeLoansBuyAHomeAboutYourFinancesPage.selectRace(homeLoansReader("race"));
            homeLoansBuyAHomeAboutYourFinancesPage.captureCurrentAddressSince(homeLoansReader("currentAddressSince"));
            homeLoansBuyAHomeAboutYourFinancesPage.selectResidentialStatus(homeLoansReader("residentialStatus"));
            homeLoansBuyAHomeAboutYourFinancesPage.selectEmployerAddressCountry(homeLoansReader("employerAddressCountry"));
            homeLoansBuyAHomeAboutYourFinancesPage.captureCurrentEmploymentSinceDate(homeLoansReader("currentEmploymentSinceDate"));
            homeLoansBuyAHomeAboutYourFinancesPage.clickHousingSchemeYesOrNo(false);
            homeLoansBuyAHomeAboutYourFinancesPage.clickContinue();

        }
    }

    public void declaration() {
        homeLoansBuyAHomePage.writeApplicationNumber();
        homeLoanBuyAHomeDeclarationPage.clickContinue();
    }

    public void thankYou() throws IOException, DataNotFoundException {
        final String fileName = "src/test/resources/testData/applicationNumber.doc";

        String text = "";
        text = this.id + " " + FileReaderManager.getInstance().getApplicationNumberReader().getApplicationNumber() + "\n";
        docWriter.writeToWordDocument(fileName, text);
        homeLoanBuyAHomeThankYouPage.clickBackToMain();
    }

    @And("^I perform tasks on the \"([^\"]*)\" tab$")
    public void iPerformTasksOnTheTab(String tab) throws IOException, DataNotFoundException {
        if (tab.equalsIgnoreCase("Before you start")) {
            homeLoansBuyAHomePage.clickContinue();
        } else if (tab.equalsIgnoreCase("Declaration")) {
            declaration();
        } else if (tab.equalsIgnoreCase("Thank You")) {
            homeLoansLandingPage.switchFrameToMain();
            thankYou();
        }

    }

    @And("^I perform tasks on the Loan details tab with multiplan as \"([^\"]*)\"$")
    public void performLoanDetails(String multiplan) throws IOException, DataNotFoundException {
        boolean multiplanOption = false;
        if (multiplan.equalsIgnoreCase("Yes")) {
            multiplanOption = true;
        }
        System.out.println(multiplanOption);
        loanDetails(multiplanOption);
    }

    @And("^I verify the client$")
    public void iVerifyTheClient() throws IOException, DataNotFoundException {
        homeLoansLandingPage.switchFrameToSideNavigation();
        homeLoansLandingPage.clickAdminFunctions();
        if (!typeOfLoan.equalsIgnoreCase("further advance")) {
            homeLoansLandingPage.clickValidationListing();
            homeLoansValidationListing.captureApplicationNumber(FileReaderManager.getInstance().getApplicationNumberReader().getApplicationNumber());
            homeLoansValidationListing.clickSearch();
            homeLoansValidationListing.clickApplicationNumberCheck();

            try {

                //homeLoansValidationListing.clickNewDevelopment();
                driver.findElement(By.name("button_newDevelopment")).click();
                driver.switchTo().alert().accept();

            } catch (UnhandledAlertException e) {
                System.out.println("Hello");

            }
             homeLoanBuyAHomeDeclarationPage.clickContinue();
             homeLoansLandingPage.switchFrameToSideNavigation();
        }

        //homeLoansLandingPage.clickAdminFunctions();
        homeLoansLandingPage.clickVerifyClient();
        homeLoansVerifyClient.captureApplicationNumber(FileReaderManager.getInstance().getApplicationNumberReader().getApplicationNumber());
        homeLoansVerifyClient.clickContinue();
        homeLoansVerifyClient.clickContinueVerification();
    }

    public String homeLoansReader(String data) throws IOException, DataNotFoundException {
        return FileReaderManager.getInstance().getDataReader().getRequiredData(data);
    }

    @And("^I perform tasks on the About you and your finances tab for buyer with ID number \"([^\"]*)\"$")
    public void iPerformTasksOnTheTabForIDNumber(String idNumber) throws IOException, DataNotFoundException, InvalidFormatException {
        this.id = homeLoanBuyAHomePropertyDetailsPage.getID(idNumber);
        aboutYouAndYourFinances(this.id);
    }

    @And("^I perform tasks on the Property details tab for seller with ID number \"([^\"]*)\" in \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
    public void iPerformTasksOnTheTabForIDNumberSuburb(String idNumber, String streetNumber, String streetName, String suburbName) throws IOException, DataNotFoundException {

        if (!typeOfLoan.equalsIgnoreCase("further advance")) {
            propertyDetails(idNumber, streetNumber, streetName, suburbName);
        }
    }

    @And("^I perform tasks on the getting started tab for further advance with account \"([^\"]*)\"$")
    public void iPerformTasksOnTheTabForFurtherAdvanceWithAccount(String loanAccNumber) throws IOException, DataNotFoundException {
        gettingStartedDetails(loanAccNumber);
    }

    @After
    public void TearDownTest(Scenario scenario) {
        if (scenario.isFailed()){
            //Take a screenshot login goes in here
        }

    }

}
