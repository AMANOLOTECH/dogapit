package za.co.absa.runners;

import com.aventstack.extentreports.gherkin.model.Feature;
import  za.co.absa.Base.ExtenReportUtil;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.IOException;

import static  za.co.absa.Base.BaseUtil.features;

public class NGTestListener implements ITestListener {

    ExtenReportUtil extenReportUtil = new ExtenReportUtil();
    @Override
    public void onTestStart(ITestResult iTestResult) {
        System.out.println("On test Pass");
    }
    @Override
    public void onTestSuccess(ITestResult iTestResult) {

    }

    @Override
    public void onTestFailure(ITestResult iTestResult) {
        System.out.println("On test failure");
        try {
            extenReportUtil.ExtentReportScreenshot();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onTestSkipped(ITestResult iTestResult) {

    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {

    }

    @Override
    public void onStart(ITestContext iTestContext) {
        System.out.println(("On Start"));
        extenReportUtil.ExtentReport();
        //To do Hard coding will be removed for adding Feature files
        features = extenReportUtil.extent.createTest(Feature.class,"HomeLoans_Login.feature" );

    }

    @Override
    public void onFinish(ITestContext iTestContext) {
        extenReportUtil.FlushReport();

    }
}
